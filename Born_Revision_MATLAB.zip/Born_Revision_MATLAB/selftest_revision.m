function report=selftest_revision()
% Small deterministic tests; errors stop a study before evaluation begins.
selftest_bookkeeping();
selftest_detector();
selftest_training_mask();
c=revision_config('pilot');c.Nx=9;c.Ny=7;c.nSensors=5;
c.fieldTolerance=1e-12;c.maxIterations=12;
op=revision_core('operators',c);rng(19,'twister');
x=0.08*randn(op.N,1);p=randn(op.N,1);p=p/norm(p);
G=revision_core('dense',op);V=randn(op.N,3)+1i*randn(op.N,3);
convErr=norm(revision_core('apply',op,V)-G*V,'fro')/norm(G*V,'fro');
[y,J,meta,U]=revision_core('forward',x,op,c,true);
Ud=(eye(op.N)-G.*x.')\op.Uinc;
fieldErr=norm(U-Ud,'fro')/norm(Ud,'fro');
e=1e-5;
yplus=revision_core('forward',x+e*p,op,c,false);
yminus=revision_core('forward',x-e*p,op,c,false);
jacErr=norm((yplus-yminus)/(2*e)-J*p)/max(norm(J*p),eps);
[y0,J0]=revision_core('forward',zeros(op.N,1),op,c,true);
zeroErr=norm(y0);bornErr=norm(J0-op.A,'fro')/norm(op.A,'fro');
Y=reshape(y,c.nSensors,c.nSensors);reciprocity=norm(Y-Y.','fro')/norm(Y,'fro');
% Non-square grid derivative ordering and boundary convention.
dx=reshape(op.Dx*op.X(:),c.Ny,c.Nx);
dy=reshape(op.Dy*op.Y(:),c.Ny,c.Nx);
temp=dx(:,1:end-1)-c.Lx;dxErr=max(abs(temp(:)));
temp=dy(1:end-1,:)-c.Ly;dyErr=max(abs(temp(:)));
priorErr=zeros(2,1);kinds={'quadratic','tv'};
for k=1:2
 [~,g]=revision_core('prior',x,op,kinds{k},c);
 vp=revision_core('prior',x+e*p,op,kinds{k},c);
 vm=revision_core('prior',x-e*p,op,kinds{k},c);
 priorErr(k)=abs((vp-vm)/(2*e)-g'*p)/max(abs(g'*p),1e-8);
end
assert(convErr<1e-11,'FFT convolution mismatch.');
assert(fieldErr<1e-9,'Iterative/dense field mismatch.');
assert(jacErr<1e-6,'Exact Jacobian finite-difference test failed.');
assert(zeroErr<1e-14 && bornErr<1e-12,'Zero-contrast/Born limit failed.');
assert(reciprocity<1e-9,'Reciprocity failed.');
assert(max([dxErr dyErr])<1e-12,'Rectangular-grid derivatives failed.');
assert(max(priorErr)<1e-5,'Prior gradient test failed.');
s=revision_core('invert',y,op,c,'nonlinear','quadratic',1e-3,zeros(op.N,1));
assert(all(diff(s.history(:,2))<=1e-12),'Accepted objective increased.');
assert(all(s.x>=c.lowerBound & s.x<=c.upperBound),'Bounds violated.');
% Force the alternative GMRES path to exercise fallback independently.
cg=c;cg.fieldMaxIterations=0;
yg=revision_core('forward',x,op,cg,false);
gmresErr=norm(yg-y)/norm(y);assert(gmresErr<1e-8,'GMRES fallback mismatch.');
% Exact metric edge cases: a perfect support and an empty prediction.
mask=(op.X.^2+op.Y.^2)<.035^2;
d=struct('targetMask',mask,'truth',.2*double(mask(:)));
m=revision_core('metrics',d.truth,d,op,.1);
assert(m.Dice==1 && m.IoU==1 && m.FPR==0 && m.Localization_m==0,'Perfect-image metric test failed.');
m=revision_core('metrics',zeros(op.N,1),d,op,.1);
assert(m.Dice==0 && m.EmptySupport && isnan(m.Localization_m) && isnan(m.FDP),'Empty-support metric test failed.');
report=struct('fftDenseRelativeError',convErr,'fieldDenseRelativeError',fieldErr, ...
 'jacobianRelativeError',jacErr,'bornLimitRelativeError',bornErr, ...
 'reciprocityRelativeError',reciprocity,'priorGradientRelativeErrors',priorErr, ...
 'gmresRelativeError',gmresErr,'fieldResidual',meta.relativeResidual, ...
 'acceptedObjectiveMonotonic',true,'passed',true);
fprintf('Self-tests passed: FFT %.2g, field %.2g, Jacobian %.2g, GMRES %.2g\n',convErr,fieldErr,jacErr,gmresErr);
end


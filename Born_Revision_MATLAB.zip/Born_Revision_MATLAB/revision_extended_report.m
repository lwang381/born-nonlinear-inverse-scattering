function revision_extended_report(root)
% Report every planned fit and matched-prior effects; never rerun inversions.
q=load(fullfile(root,'last_run_config.mat'),'c');c=q.c;
q=load(fullfile(root,'analysis_tables.mat'),'T');T=q.T;
P=T(T.Threshold==c.primaryThreshold,:);names=revision_methods();
ids=1:13;if strcmp(c.mode,'pilot'),ids=[1 12 13];end
coverage=struct([]);
for id=ids
 for tr=c.trialIDs
  for mi=1:numel(names)
   a=P(P.Condition==id&P.Trial==tr&strcmp(P.Method,names{mi}),:);
   r=struct('Condition',id,'Trial',tr,'Method',names{mi},'Present',height(a)==1,'Success',false,'Converged',false);
   if r.Present,r.Success=a.Success;r.Converged=a.Converged;end
   coverage=revision_append_record(coverage,r);
  end
 end
end
C=struct2table(coverage);writetable(C,fullfile(root,'planned_run_coverage.csv'));
pairs={'Born_Q','NL_Q_BornQ';'Born_TV','NL_TV_BornQ';'Born_Q','NL_TV_BornQ';'NL_TV_BornQ','NL_TV_Zero'};
rows=struct([]);pairedTrials=struct([]);rng(c.seed+710000,'twister');
for id=ids
 for pi=1:size(pairs,1)
  for threshold=c.thresholds
   A=T(T.Condition==id&strcmp(T.Method,pairs{pi,1})&T.Threshold==threshold,:);
   B=T(T.Condition==id&strcmp(T.Method,pairs{pi,2})&T.Threshold==threshold,:);
   [~,ia,ib]=intersect(A.Trial,B.Trial);A=A(ia,:);B=B(ib,:);
   good=A.Success&B.Success&isfinite(A.Dice)&isfinite(B.Dice)&isfinite(A.FullMisfit)&isfinite(B.FullMisfit);
   A=A(good,:);B=B(good,:);n=height(A);if n==0,continue;end
   dd=B.Dice-A.Dice;dm=A.FullMisfit-B.FullMisfit;
   for k=1:n
    r=struct('Condition',id,'Trial',A.Trial(k),'Reference',pairs{pi,1},'Comparison',pairs{pi,2}, ...
     'Threshold',threshold,'DiceGain',dd(k),'FullMisfitGain',dm(k), ...
     'LocalizationGain_m',A.Localization_m(k)-B.Localization_m(k), ...
     'PipelineSecondsDifference',B.PipelineSeconds(k)-A.PipelineSeconds(k), ...
     'BothConverged',A.Converged(k)&&B.Converged(k));
    pairedTrials=revision_append_record(pairedTrials,r);
   end
   idx=randi(n,n,c.bootstrapSamples);bd=mean(dd(idx),1);bm=mean(dm(idx),1);
   for tm=c.misfitCutoffs
    for td=c.diceCutoffs
     code=revision_gain_category(mean(dm),mean(dd),tm,td);
     bc=revision_gain_category(bm,bd,tm,td);
     r=struct('Condition',id,'Reference',pairs{pi,1},'Comparison',pairs{pi,2}, ...
      'Threshold',threshold,'MisfitCutoff',tm,'DiceCutoff',td,'ValidPairs',n, ...
      'BothConverged',nnz(A.Converged&B.Converged),'MeanDiceGain',mean(dd),'MeanFullMisfitGain',mean(dm), ...
      'Category',code,'BootstrapFractionSameCategory',mean(bc==code));
     rows=revision_append_record(rows,r);
    end
   end
  end
 end
end
if ~isempty(rows),writetable(struct2table(rows),fullfile(root,'matched_prior_category_sensitivity.csv'));end
if ~isempty(pairedTrials),writetable(struct2table(pairedTrials),fullfile(root,'paired_trial_effects.csv'));end
q=load(fullfile(root,'calibration','locked_calibration.mat'),'cal');cal=q.cal;
fid=fopen(fullfile(root,'completion_status.txt'),'w');assert(fid>=0);cl=onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'Expected %d; present %d; successful %d; converged %d\n',height(C),nnz(C.Present),nnz(C.Success),nnz(C.Converged));
fprintf(fid,'Complete and all converged: %d\n',all(C.Present&C.Success&C.Converged));
fprintf(fid,'Calibration bracketed by completed candidates: %d\n',cal.bracketed);
fprintf(fid,'Not a publication/acceptance certificate. Report counts, intervals and limitations.\n');
fprintf(fid,'New evaluation seed; do not pool v1.0.3 and v1.0.4 records. All 5 methods in every cell.\n');
if ~c.makeFigures,return;end
% Original MATLAB-generated figure: mean paired effect with exploratory CI.
D=readtable(fullfile(root,'paired_differences.csv'));
f=figure('Visible','off','Color','w','Position',[50 50 1450 700]);tiledlayout(2,2);
for pi=1:2
 for zi=1:2
  met={'Dice','FullMisfit'};nexttile;
  a=D(strcmp(D.Reference,pairs{pi,1})&strcmp(D.Comparison,pairs{pi,2})& ...
   strcmp(D.Metric,met{zi})&D.Threshold==c.primaryThreshold,:);
  a=sortrows(a,'Condition');mu=a.Mean_B_minus_A;lo=a.Lower95;hi=a.Upper95;
  if zi==2,mu=-mu;temp=lo;lo=-hi;hi=-temp;end
  errorbar(a.Condition,mu,mu-lo,hi-mu,'o','LineWidth',1.2);yline(0,'k:');grid on;
  xlabel('Condition (13 = separate layered test)');ylabel([met{zi} ' improvement']);
  title([pairs{pi,1} ' to ' pairs{pi,2}],'Interpreter','none');
 end
end
sgtitle(sprintf('Matched-prior paired effects; %d planned trials per condition; exploratory 95%% intervals',numel(c.trialIDs)));
exportgraphics(f,fullfile(root,'figures','matched_prior_effects.png'),'Resolution',240);close(f);
% Threshold sensitivity shown for all methods, without changing locked rule.
f=figure('Visible','off','Color','w','Position',[50 50 950 550]);hold on;
for mi=1:numel(names)
 th=sort(c.thresholds);means=NaN(size(th));
 for ti=1:numel(th)
  a=T(strcmp(T.Method,names{mi})&T.Threshold==th(ti)&T.Success,:);
  if ~isempty(a),means(ti)=mean(a.Dice);end
 end
 plot(th,means,'-o','DisplayName',names{mi});
end
xline(c.primaryThreshold,'k:','Locked primary');grid on;legend('Interpreter','none','Location','best');
xlabel('Relative support threshold');ylabel('Mean Dice over successful evaluation fits');
title('All conditions pooled; see tables for failures and condition-specific effects');
exportgraphics(f,fullfile(root,'figures','detector_threshold_sensitivity.png'),'Resolution',240);close(f);
end

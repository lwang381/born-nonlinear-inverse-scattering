function detector=revision_detector_development(op,c,cal,root)
% Independent labelled development set; never reads evaluation case files.
% Equal weighting across 12 scenes and 5 methods; one rule for all methods.
out=fullfile(root,'detector_development');if ~exist(out,'dir'),mkdir(out);end
lock=fullfile(out,'locked_detector.mat');
if exist(lock,'file'),q=load(lock,'detector');detector=q.detector;return;end
assert(c.detectorDevelopmentCases==12,'This version fixes 12 detector-development scenes.');
cdv=c;cdv.maxIterations=c.calibrationMaxIterations;
cdv.pcgMaxIterations=c.calibrationPCGMaxIterations;
% Separate from evaluation and calibration seeds, including across resolutions.
cdv.seed=c.detectorSeed;
methods={'Born_Q','Born_TV','NL_Q_BornQ','NL_TV_BornQ','NL_TV_Zero'};
rules={'largest','all'};thresholds=[.10 .20 .35 .50];
rows=struct([]);checks=struct([]);truthRows=struct([]);sceneID=0;
for bg={'correlated','layered'}
 for h=[.02 .06 .10]
  for amp=[.05 .35]
   sceneID=sceneID+1;cond=struct('id',100+sceneID,'h',h,'contrast',amp,'background',bg{1});
   file=fullfile(out,sprintf('scene_%02d.mat',sceneID));
   if exist(file,'file'),q=load(file,'payload');payload=q.payload;
   else
    payload=struct('data',revision_core('scene',op,cdv,cond,1,true),'solutions',struct());
    save(file,'payload','-v7');
   end
   d=payload.data;
   for mi=1:numel(methods)
    name=methods{mi};
    if ~isfield(payload.solutions,name)
     fprintf('Detector development %02d/12 | %s\n',sceneID,name);
     if startsWith(name,'Born'),model='linear';else,model='nonlinear';end
     if contains(name,'TV'),kind='tv';lam=cal.lambdaTV;else,kind='quadratic';lam=cal.lambdaQ;end
     x0=zeros(op.N,1);
     if contains(name,'BornQ'),x0=payload.solutions.Born_Q.x;end
     sol=revision_core('invert',d.y,op,cdv,model,kind,lam,x0);
     payload.solutions.(name)=sol;save(file,'payload','-v7');
    end
    sol=payload.solutions.(name);
    checks=revision_append_record(checks,struct('Scene',sceneID,'Method',name, ...
     'Seed',d.seed,'Converged',sol.converged,'Stop',sol.status, ...
     'Iterations',sol.iterations,'FinalProjectedGradient',sol.history(end,5)));
    for ri=1:2
     for ti=1:4
      m=revision_core('metrics',sol.x,d,op,thresholds(ti),rules{ri});
      rec=struct('Scene',sceneID,'Method',name,'Rule',rules{ri},'Threshold',thresholds(ti), ...
       'Dice',m.Dice,'Precision',m.Precision,'Recall',m.Recall,'FPR',m.FPR, ...
       'AreaFraction',nnz(m.support)/op.N);
      rows=revision_append_record(rows,rec);
     end
    end
   end
   for ri=1:2
    for ti=1:4
     m=revision_core('metrics',d.truth,d,op,thresholds(ti),rules{ri});
     truthRows=revision_append_record(truthRows,struct('Scene',sceneID,'Rule',rules{ri}, ...
      'Threshold',thresholds(ti),'Dice',m.Dice,'FPR',m.FPR,'AreaFraction',nnz(m.support)/op.N));
    end
   end
  end
 end
end
T=struct2table(rows);C=struct2table(checks);
writetable(T,fullfile(out,'candidate_metrics.csv'));
writetable(C,fullfile(out,'convergence.csv'));
writetable(struct2table(truthRows),fullfile(out,'exact_truth_diagnostics.csv'));
assert(all(C.Converged),['Detector selection stopped: development fits did not all converge. ' ...
 'Inspect detector_development/convergence.csv before changing the protocol.']);
[detector,S]=revision_select_detector(T);
writetable(S,fullfile(out,'candidate_summary.csv'));
detector.developmentScenes=12;detector.methods=methods;
detector.selectionRule=['Maximum equally weighted scene/method mean Dice; ties within 1e-12 use ' ...
 'lower mean FPR, then fixed candidate order. No evaluation data used.'];
save(lock,'detector','-v7');
fprintf('Locked detector: %s components, threshold %.2f; development mean Dice %.3f\n', ...
 detector.rule,detector.threshold,detector.meanDevelopmentDice);
end


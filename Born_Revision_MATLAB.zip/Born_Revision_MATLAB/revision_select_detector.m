function [detector,S]=revision_select_detector(T)
% Each candidate must cover every scene/method pair, with finite Dice/FPR.
rules={'largest','all'};thresholds=[.10 .20 .35 .50];rows=struct([]);
sceneIDs=unique(T.Scene);methods=unique(T.Method);expected=numel(sceneIDs)*numel(methods);
for ri=1:2
 for ti=1:4
  A=T(strcmp(T.Rule,rules{ri}) & T.Threshold==thresholds(ti),:);
  assert(height(A)==expected,'Incomplete candidate coverage.');
  assert(height(unique(A(:,{'Scene','Method'}),'rows'))==expected,'Duplicate scene/method pair.');
  assert(all(isfinite(A.Dice)) && all(isfinite(A.FPR)),'Undefined selection metrics.');
  rows=revision_append_record(rows,struct('Rule',rules{ri},'Threshold',thresholds(ti), ...
   'MeanDice',mean(A.Dice),'MeanFPR',mean(A.FPR),'Pairs',height(A)));
 end
end
S=struct2table(rows);best=max(S.MeanDice);eligible=find(S.MeanDice>=best-1e-12);
[~,k]=min(S.MeanFPR(eligible));ix=eligible(k);
detector=struct('rule',S.Rule{ix},'threshold',S.Threshold(ix), ...
 'meanDevelopmentDice',S.MeanDice(ix),'meanDevelopmentFPR',S.MeanFPR(ix));
end


function selftest_bookkeeping()
% Regression for the first-record calibration error and subsequent records.
r=struct('development',1,'candidate',1,'lambda',1e-4,'method','Born_Q', ...
 'validationError',0.1,'converged',true,'success',true);
a=revision_append_record(struct([]),r);
assert(isequal(a,r),'First record was not initialized correctly.');
r.development=2;r.method='NL_TV_Zero';r.validationError=Inf;r.converged=false;r.success=false;
a=revision_append_record(a,orderfields(r));
assert(numel(a)==2 && isequal(a(2),orderfields(r,a)), ...
 'Second record or field-order normalization failed.');
T=struct2table(a);
assert(height(T)==2 && T.development(2)==2 && ~T.success(2), ...
 'Record-to-table conversion failed.');
assert(iscell(T.method) && strcmp(T.method{2},'NL_TV_Zero'),'Text column mismatch.');
rejected=false;
try
 bad=rmfield(r,'success');revision_append_record(a,bad);
catch ME
 rejected=strcmp(ME.identifier,'revision:RecordSchema');
end
assert(rejected,'A mismatched schema must be rejected explicitly.');
% Exercise zero-row typed collections as well as fieldless struct([]).
emptyTyped=repmat(r,0,1);b=revision_append_record(emptyTyped,r);
assert(isequal(b,r),'Typed empty collection initialization failed.');
fprintf('Bookkeeping tests passed: first record, append, field order, table, schema guard.\n');
end


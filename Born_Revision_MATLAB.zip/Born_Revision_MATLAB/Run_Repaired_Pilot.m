% Low-resolution workflow check only. Never pool with paper-scale results.
run_revision('pilot');

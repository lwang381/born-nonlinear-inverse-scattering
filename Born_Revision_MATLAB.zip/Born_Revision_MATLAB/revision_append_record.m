function records=revision_append_record(records,record)
% Append homogeneous scalar records, initializing the first record by value.
% MATLAB rejects indexed assignment of a populated struct into struct([]).
assert(isstruct(records) && isstruct(record) && isscalar(record), ...
 'revision:RecordType','Expected a struct collection and a scalar struct record.');
if isempty(records)
 records=record;
 return;
end
oldFields=fieldnames(records);newFields=fieldnames(record);
assert(isequal(sort(oldFields),sort(newFields)), ...
 'revision:RecordSchema','A record has missing or additional fields.');
record=orderfields(record,records);
records(end+1)=record;
end


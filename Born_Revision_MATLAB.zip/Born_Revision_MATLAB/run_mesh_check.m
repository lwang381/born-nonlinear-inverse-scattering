function results=run_mesh_check(gridSizes)
% Optional inexpensive FORWARD discretisation check, not inversion benchmark.
% Same analytic smooth background + circular target on each cell-centred grid.
% Finest grid is a numerical reference, not ground truth or an exact solution.
if nargin==0,gridSizes=[24 48 72];end
assert(numel(gridSizes)>=2 && all(diff(gridSizes)>0),'Supply increasing grids.');
c=revision_config('stage1');ys=cell(numel(gridSizes),2);secs=zeros(numel(gridSizes),2);
rows=struct([]);hvals=[0.02 0.10];
for k=1:numel(gridSizes)
 c.Nx=gridSizes(k);c.Ny=gridSizes(k);op=revision_core('operators',c);
 for j=1:2
  % Analytic field has a fixed amplitude scale, not grid-dependent random draws.
  bg=hvals(j)*(sin(2*pi*op.X/.09)+0.6*cos(2*pi*op.Y/.12));
  mask=(op.X-.02).^2+(op.Y-.02).^2<=c.targetRadius^2;
  truth=bg+.35*mask;t=tic;
  ys{k,j}=revision_core('forward',truth(:),op,c,false);secs(k,j)=toc(t);
 end
end
q=0;
for k=1:numel(gridSizes)
 for j=1:2
  q=q+1;rows=revision_append_record(rows,struct('Grid',gridSizes(k),'BackgroundAmplitude',hvals(j), ...
   'RelativeDifferenceToFinest',norm(ys{k,j}-ys{end,j})/norm(ys{end,j}), ...
   'ForwardSeconds',secs(k,j),'ReferenceGrid',gridSizes(end))); %#ok<AGROW>
 end
end
results=struct2table(rows);disp(results);
folder=fullfile(fileparts(mfilename('fullpath')),'mesh_check');if ~exist(folder,'dir'),mkdir(folder);end
writetable(results,fullfile(folder,'forward_grid_check.csv'));
save(fullfile(folder,'forward_grid_check.mat'),'results','ys','gridSizes');
fprintf('Compare discretisation differences with noise and the claimed model differences.\n');
end


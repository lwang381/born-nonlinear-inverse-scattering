function bundle=pack_revision_results(root)
% Full review bundle, including figures, sources and all failed checkpoints.
root=char(root);files=dir(fullfile(root,'**','*'));relative={};
for k=1:numel(files)
 if files(k).isdir,continue;end
 [~,~,ext]=fileparts(files(k).name);
 if ~ismember(lower(ext),{'.mat','.csv','.txt','.m','.png','.md','.json','.ps1'}),continue;end
 p=fullfile(files(k).folder,files(k).name);
 relative{end+1}=p(numel(root)+2:end); %#ok<AGROW>
end
bundle=fullfile(root,'revision_review_bundle_v104.zip');
zip(bundle,relative,root);fprintf('Upload this review bundle: %s\n',bundle);
end

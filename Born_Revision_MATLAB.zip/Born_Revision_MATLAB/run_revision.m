function run_revision(mode,overrides)
% RUN_REVISION('pilot'|'stage1'|'stage2') -- restart-safe controlled study.
% Optional scalar struct overrides are locked in protocol.mat before runs.
if nargin<1,mode='pilot';end
c=revision_config(mode);
if nargin>1
 names=fieldnames(overrides);
 for k=1:numel(names)
  assert(isfield(c,names{k}),'Unknown configuration field: %s',names{k});
  c.(names{k})=overrides.(names{k});
 end
end
assert(numel(c.heterogeneity)==3 && numel(c.contrasts)==4,'This protocol requires a 3 x 4 operating grid.');
assert(c.developmentCases==2,'This version prespecifies two development scenes.');
assert(c.primaryThreshold==c.thresholds(1),'First threshold must be primary.');
assert(c.Nx>=7 && c.Ny>=7 && c.nSensors>=5,'Grid/array too small.');
root=c.outputRoot;if ~exist(root,'dir'),mkdir(root);end
for n={'cases','calibration','figures','source_snapshot'}
 if ~exist(fullfile(root,n{1}),'dir'),mkdir(fullfile(root,n{1}));end
end
diary(fullfile(root,'run_log.txt'));cleaner=onCleanup(@() diary('off')); %#ok<NASGU>
fprintf('\n%s | %s | %s\n',c.version,c.mode,datestr(now,31));
% Preserve and compare the actual code text, not only a manually set version.
srcRoot=fileparts(mfilename('fullpath'));
files=[dir(fullfile(srcRoot,'*.m'));dir(fullfile(srcRoot,'*.ps1'))];
[~,order]=sort({files.name});files=files(order);sourceText='';
for k=1:numel(files)
 txt=fileread(fullfile(files(k).folder,files(k).name));
 sourceText=[sourceText files(k).name newline txt newline]; %#ok<AGROW>
end
protocol=rmfield(c,{'mode','repeats','trialIDs','outputRoot','makeFigures'});
manifest=fullfile(root,'protocol.mat');
if exist(manifest,'file')
 old=load(manifest,'protocol','sourceText');
 assert(isequaln(protocol,old.protocol) && strcmp(sourceText,old.sourceText), ...
  'Protocol or source changed. Use a NEW outputRoot; do not mix experiments.');
else
 environment=struct('matlabVersion',version,'computer',computer,'toolboxes',ver, ...
  'date',datestr(now,31),'unknownTotalContrast',true,'materialLossSimulated',false);
 if ispc
  [~,cpu]=system('powershell -NoProfile -Command "(Get-CimInstance Win32_Processor).Name"');
 else,[~,cpu]=system('uname -a');end
 environment.cpuDescription=strtrim(cpu);
 save(manifest,'protocol','sourceText','environment','-v7');
 for k=1:numel(files),copyfile(fullfile(files(k).folder,files(k).name),fullfile(root,'source_snapshot',files(k).name));end
 copyfile(fullfile(srcRoot,'regression_fixtures'),fullfile(root,'source_snapshot','regression_fixtures'));
 copyfile(fullfile(srcRoot,'README.md'),fullfile(root,'source_snapshot','README.md'));
 copyfile(fullfile(srcRoot,'PATCH_NOTES.md'),fullfile(root,'source_snapshot','PATCH_NOTES.md'));
end
checks=selftest_revision(); checks.savedCases=selftest_saved_cases(); checks.protocol=selftest_protocol();
save(fullfile(root,'selftest_results.mat'),'checks');
t=tic;op=revision_core('operators',c);setupSeconds=toc(t);
save(fullfile(root,'operators.mat'),'op','setupSeconds','-v7');
fprintf('Grid %d x %d, %d channels; stored operators %.1f MiB; setup %.2f s.\n',c.Nx,c.Ny,op.nData,op.storedBytes/2^20,setupSeconds);
cal=revision_calibrate(op,c,root);
if c.requireBracketedCalibration && ~cal.bracketed
 pack_development_diagnostics(root);
 error('Calibration is not bracketed by converged candidates. See calibration and diagnostic ZIP; evaluation has not started.');
end
detector=revision_detector_development(op,c,cal,root);
c.primaryThreshold=detector.threshold;c.detectorRule=detector.rule;
c.thresholds=[c.primaryThreshold c.thresholds(c.thresholds~=c.primaryThreshold)];
save(fullfile(root,'effective_config.mat'),'c');
if strcmp(c.mode,'development')
 pack_development_diagnostics(root); fprintf('Development complete. Run stage1 or stage2 without editing source/config.\n'); return;
end
conds=conditions(c);caseIDs=1:numel(conds);
if strcmp(c.mode,'pilot'),caseIDs=[1 12 13];end
for ci=caseIDs
 cond=conds(ci);names=revision_methods();
 for trial=c.trialIDs
  file=fullfile(root,'cases',sprintf('condition_%02d_trial_%03d.mat',cond.id,trial));
  if exist(file,'file'),tmp=load(file,'payload');payload=tmp.payload;
  else
   payload=struct('condition',cond,'trial',trial,'solutions',struct(),'sceneSuccess',false);
   try
    payload.data=revision_core('scene',op,c,cond,trial,false);payload.sceneSuccess=true;
   catch ME
    payload.sceneError=getReport(ME,'extended','hyperlinks','off');
    atomicSave(file,payload);warning('Scene failed: %s',ME.message);continue;
   end
  end
  if ~payload.sceneSuccess,warning('Existing failed scene retained: %s',file);continue;end
  d=payload.data;
  for j=1:numel(names)
   name=names{j};if isfield(payload.solutions,name),continue;end
   fprintf('Condition %02d/%02d | trial %d | %s\n',cond.id,numel(conds),trial,name);
   entry=struct('success',false,'error','');
   try
    if startsWith(name,'Born'),model='linear';else,model='nonlinear';end
    if contains(name,'TV'),kind='tv';lambda=cal.lambdaTV;else,kind='quadratic';lambda=cal.lambdaQ;end
    x0=zeros(op.N,1);initializationSeconds=0;
    if contains(name,'BornQ')
     b=payload.solutions.Born_Q;assert(b.success,'Born initializer failed.');
     x0=b.solver.x;initializationSeconds=b.solver.seconds;
    end
    s=revision_core('invert',d.y,op,c,model,kind,lambda,x0);
    t=tic;fullPrediction=revision_core('forward',s.x,op,c,false);evaluationSeconds=toc(t);
    mets=cell(numel(c.thresholds),1);
    for it=1:numel(c.thresholds),mets{it}=revision_core('metrics',s.x,d,op,c.thresholds(it),c.detectorRule);end
    entry.success=true;entry.solver=s;entry.metrics=mets;
    entry.nativeMisfit=norm(d.y-s.nativePrediction)/norm(d.y);
    entry.fullMisfit=norm(d.y-fullPrediction)/norm(d.y);
    entry.fullPrediction=fullPrediction;entry.evaluationSeconds=evaluationSeconds;
    entry.initializationSeconds=initializationSeconds;
    entry.pipelineSeconds=s.seconds+initializationSeconds;
   catch ME
    entry.error=getReport(ME,'extended','hyperlinks','off');warning('%s failed: %s',name,ME.message);
   end
   payload.solutions.(name)=entry;atomicSave(file,payload);
  end
 end
end
save(fullfile(root,'last_run_config.mat'),'c');
revision_report(root);
revision_extended_report(root);
pack_revision_results(root);
fprintf('\nFinished. Read readiness.txt and all failure/convergence flags in:\n%s\n',root);
end

function cs=conditions(c)
k=0;cs=struct([]);
for h=c.heterogeneity
 for amp=c.contrasts
  k=k+1;cs=revision_append_record(cs,struct('id',k,'h',h,'contrast',amp,'background','correlated')); %#ok<AGROW>
 end
end
cs=revision_append_record(cs,struct('id',13,'h',0.06,'contrast',0.35,'background','layered'));
end

function atomicSave(file,payload)
parent=fileparts(file);tmp=[tempname(parent) '.mat'];
save(tmp,'payload','-v7');[ok,msg]=movefile(tmp,file,'f');assert(ok,'%s',msg);
end


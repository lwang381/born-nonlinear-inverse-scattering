function cfg = revision_config(mode)
% Configuration fixed before evaluation. Requires MATLAB R2020b or newer.
if nargin==0, mode='pilot'; end
cfg.version='BR-1.0.4'; cfg.mode=lower(char(mode));
cfg.Nx=48; cfg.Ny=48; cfg.Lx=0.18; cfg.Ly=0.18;
cfg.frequency=1.5e9; cfg.c0=299792458;
cfg.nSensors=20; cfg.arrayRadius=0.14; cfg.targetRadius=0.018;
cfg.noiseSNRdB=25; cfg.seed=73129;
cfg.lowerBound=-0.6; cfg.upperBound=0.8;
cfg.tvEpsilon=0.01; cfg.maxIterations=100;
cfg.pcgTolerance=1e-4; cfg.pcgMaxIterations=300;
cfg.gradientTolerance=1e-5; cfg.objectiveTolerance=1e-7;
cfg.updateTolerance=1e-5; cfg.maxLineSearch=18;
cfg.fieldTolerance=1e-10; cfg.fieldMaxIterations=100;
cfg.gmresRestart=40; cfg.gmresCycles=15;
cfg.thresholds=[0.10 0.20 0.35 0.50]; cfg.primaryThreshold=0.10;
cfg.misfitCutoffs=[0.08 0.10 0.12]; cfg.diceCutoffs=[0.04 0.05 0.06];
cfg.bootstrapSamples=2000;
cfg.lambdaCandidatesQ=[1e-4 1e-3 1e-2 1e-1 1 10 100];
cfg.lambdaCandidatesTV=[1e-7 1e-6 1e-5 1e-4 1e-3 1e-2 1e-1 1];
cfg.calibrationMaxIterations=400;cfg.calibrationPCGMaxIterations=600;
cfg.calibrationRetryMaxIterations=800;
cfg.calibrationSeed=273129;cfg.detectorSeed=473129;
cfg.requireBracketedCalibration=true;
cfg.detectorRule='largest';cfg.detectorDevelopmentCases=12;
cfg.developmentCases=2;
cfg.heterogeneity=[0.02 0.06 0.10]; cfg.contrasts=[0.05 0.10 0.20 0.35];
cfg.repeats=5; cfg.trialIDs=1:5;
cfg.outputRoot=fullfile(fileparts(mfilename('fullpath')),['results_' cfg.mode '_v104']);
cfg.makeFigures=true;
switch cfg.mode
 case 'pilot'
  cfg.Nx=24; cfg.Ny=24; cfg.nSensors=12;
  cfg.repeats=1; cfg.trialIDs=1;
  % Three conditions including a structured scene, all five methods.
 case {'stage1','development'}
  cfg.seed=673129; % Fresh evaluation scenes; development uses separate fixed seeds.
  % All five methods: 13 conditions x 5 scenes x 5 = 325 fits.
  cfg.outputRoot=fullfile(fileparts(mfilename('fullpath')),'results_stage1_v104');
 case 'stage2'
  cfg.seed=673129;
  cfg.repeats=10; cfg.trialIDs=1:10;
  cfg.outputRoot=fullfile(fileparts(mfilename('fullpath')),'results_stage1_v104');
  % All cells expanded uniformly to ten; completed stage1 trials reused.
 otherwise
  error('Mode must be pilot, development, stage1, or stage2.');
end
end


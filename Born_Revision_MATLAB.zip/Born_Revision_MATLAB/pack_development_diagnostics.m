function bundle=pack_development_diagnostics(root)
% Package partial development evidence even if a convergence gate stops a run.
if nargin==0,c=revision_config('pilot');root=c.outputRoot;end
out=fullfile(root,'review_only');if ~exist(out,'dir'),mkdir(out);end
files=dir(fullfile(root,'**','*'));relative={};
for k=1:numel(files)
 if files(k).isdir,continue;end
 [~,~,ext]=fileparts(files(k).name);
 if ~ismember(lower(ext),{'.mat','.csv','.txt'}),continue;end
 path=fullfile(files(k).folder,files(k).name);
 relative{end+1}=path(numel(root)+2:end); %#ok<AGROW>
end
bundle=fullfile(out,'development_diagnostics.zip');
if ~isempty(relative),zip(bundle,relative,root);end
fprintf('Partial development diagnostics: %s\n',bundle);
end


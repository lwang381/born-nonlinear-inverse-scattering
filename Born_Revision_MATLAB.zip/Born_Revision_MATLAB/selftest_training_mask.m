function report=selftest_training_mask()
c=revision_config('pilot');c.Nx=7;c.Ny=7;c.nSensors=5;c.maxIterations=80;
c.gradientTolerance=1e-7;c.pcgTolerance=1e-7;
op=revision_core('operators',c);truth=.08*exp(-(op.X(:).^2+op.Y(:).^2)/.001);
y=revision_core('forward',truth,op,c,false);
[i,j]=ndgrid(1:c.nSensors);mask=mod(min(i,j)+3*max(i,j),5)~=0;mask=mask(:);
yChanged=y;yChanged(~mask)=yChanged(~mask)+100*norm(y)*(1+1i);
for model={'linear','nonlinear'}
 a=revision_core('invert',y,op,c,model{1},'quadratic',.1,zeros(op.N,1),mask);
 b=revision_core('invert',yChanged,op,c,model{1},'quadratic',.1,zeros(op.N,1),mask);
 assert(isequal(a.trainingMask,mask)&&a.trainingChannels==nnz(mask),'Supplied mask was discarded.');
 assert(abs(a.dataScale-norm(y(mask)))<1e-12*max(norm(y(mask)),1),'Wrong training normalization.');
 assert(norm(a.x-b.x)<=1e-11*max(norm(a.x),1),'Held-out values affected training solution.');
 assert(isequal(size(a.history),size(b.history))&&max(abs(a.history(:)-b.history(:)))<1e-10, ...
  'Held-out measurements changed the optimization path.');
end
report=struct('passed',true,'trainingChannels',nnz(mask),'heldOutChannels',nnz(~mask));
fprintf('Training-mask regression passed for linear and nonlinear solvers.\n');
end

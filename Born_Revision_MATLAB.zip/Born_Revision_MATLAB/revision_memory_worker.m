function revision_memory_worker(inputFile,outputFile,marker)
% Invoked only in the fresh MATLAB process by the external sampler.
q=load(inputFile);c=q.c;cal=q.cal;y=q.y;name=q.method;clear q;
op=revision_core('operators',c);p=System.Diagnostics.Process.GetCurrentProcess();p.Refresh();
baselineMiB=double(p.WorkingSet64)/2^20;
fid=fopen(marker,'w');assert(fid>=0);fprintf(fid,'%d',feature('getpid'));fclose(fid);
cleanup=onCleanup(@() removeMarker(marker)); %#ok<NASGU>
pause(.25); % Give external sampler time to attach; not included in timing.
t=tic;x0=zeros(op.N,1);
if contains(name,'BornQ')
 b=revision_core('invert',y,op,c,'linear','quadratic',cal.lambdaQ,x0);x0=b.x;
end
if startsWith(name,'Born'),model='linear';else,model='nonlinear';end
if contains(name,'TV'),kind='tv';lam=cal.lambdaTV;else,kind='quadratic';lam=cal.lambdaQ;end
s=revision_core('invert',y,op,c,model,kind,lam,x0);elapsed=toc(t);
p.Refresh();lifetimePeakMiB=double(p.PeakWorkingSet64)/2^20;
removeMarker(marker);
result=struct('converged',s.converged,'pipelineSeconds',elapsed,'baselineMiB',baselineMiB, ...
 'lifetimePeakMiB',lifetimePeakMiB,'status',s.status,'solver',s);
save(outputFile,'result','-v7');
end
function removeMarker(marker)
if exist(marker,'file'),delete(marker);end
end

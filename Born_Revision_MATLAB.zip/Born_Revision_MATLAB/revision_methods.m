function names=revision_methods()
% All methods run in every condition, in initializer-safe order.
names={'Born_Q','Born_TV','NL_Q_BornQ','NL_TV_BornQ','NL_TV_Zero'};
end

function benchmark_revision_memory(root)
% Optional Windows benchmark. Each method gets a fresh MATLAB child process.
% External 20-ms sampling reports active-pipeline process working set, NOT
% exact allocation peak or memory attributable solely to the inversion.
if nargin<1,c=revision_config('stage2');root=c.outputRoot;end
assert(ispc,'This optional external sampler requires Windows PowerShell.');
q=load(fullfile(root,'effective_config.mat'),'c');c=q.c;
q=load(fullfile(root,'calibration','locked_calibration.mat'),'cal');cal=q.cal;
pkg=fileparts(mfilename('fullpath'));folder=fullfile(root,'memory_benchmark');
if ~exist(folder,'dir'),mkdir(folder);end
exe=fullfile(matlabroot,'bin','matlab.exe');sampler=fullfile(pkg,'sample_matlab_memory.ps1');
methods=revision_methods();records=struct([]);
for id=[1 4 12 13]
 q=load(fullfile(root,'cases',sprintf('condition_%02d_trial_001.mat',id)),'payload');
 assert(q.payload.sceneSuccess,'Benchmark scene failed.');y=q.payload.data.y;clear q;
 for mi=1:numel(methods)
  method=methods{mi};stem=sprintf('condition_%02d_%s',id,method);
  input=fullfile(folder,[stem '_input.mat']);output=fullfile(folder,[stem '_result.mat']);
  marker=fullfile(folder,[stem '_active.txt']);sample=fullfile(folder,[stem '_samples.csv']);
  save(input,'c','cal','y','method','-v7');
  if ~exist(output,'file')||~exist(sample,'file')
   if exist(marker,'file'),delete(marker);end
   args={sampler,exe,pkg,input,output,marker,sample};
   for k=1:numel(args),assert(~contains(args{k},'"'),'Double quotes are unsupported in benchmark paths.');end
   cmd=sprintf('powershell -NoProfile -File "%s" -MatlabExe "%s" -Package "%s" -InputFile "%s" -OutputFile "%s" -Marker "%s" -SampleFile "%s"',args{:});
   fprintf('Fresh-process memory benchmark: %s\n',stem);
   [status,msg]=system(cmd);assert(status==0,'Memory sampler failed: %s',msg);
  end
  q=load(output,'result');r=q.result;
  S=readtable(sample);peak=NaN;
  if ~isempty(S),peak=max(S.WorkingSetMiB);end
  rec=struct('Condition',id,'Trial',1,'Method',method,'Converged',r.converged, ...
   'PipelineSeconds',r.pipelineSeconds,'BaselineWorkingSetMiB',r.baselineMiB, ...
   'SampledActiveProcessPeakMiB',peak,'SampledIncreaseMiB',peak-r.baselineMiB, ...
   'Samples',height(S),'SamplingIntervalMs',20,'ProcessLifetimePeakMiB',r.lifetimePeakMiB);
  records=revision_append_record(records,rec);
  writetable(struct2table(records),fullfile(folder,'fresh_process_memory.csv'));
 end
end
fid=fopen(fullfile(folder,'measurement_notes.txt'),'w');cl=onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,['Each method uses a fresh MATLAB process and rebuilds the same operators.\n' ...
 'Baseline is taken after loading/building operators. Active sampling includes Born initialization when needed.\n' ...
 'External sampler target interval is 20 ms; OS scheduling can increase it. Samples may miss short transients.\n' ...
 'Working set includes MATLAB, operators and allocator overhead. Baseline subtraction is descriptive, not exact solver allocation.\n' ...
 'Lifetime peak includes process startup; do not call it solver peak. Missing samples are NaN, not zero.\n' ...
 'One timing per method/selected scene in this benchmark; main repeated-study timings remain primary.\n']);
pack_revision_results(root);
end

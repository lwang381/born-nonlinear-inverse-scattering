% Run from the extracted folder. 
% Fresh, uniform 10-trial evaluation: 13 conditions x 10 x 5 = 650 fits.
% Restart this script after interruption; completed checkpoints are reused.
clearvars;
packageRoot=fileparts(mfilename('fullpath'));addpath(packageRoot);
try
 run_revision('stage2');
catch ME
 c=revision_config('stage2');
 if exist(c.outputRoot,'dir'),pack_development_diagnostics(c.outputRoot);end
 rethrow(ME);
end

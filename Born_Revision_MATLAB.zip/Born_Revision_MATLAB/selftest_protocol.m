function report=selftest_protocol()
% Regressions for endpoint selection, fairness, and category sensitivity.
c=revision_config('stage1');d=revision_config('stage2');
assert(c.seed==d.seed&&strcmp(c.outputRoot,d.outputRoot),'Stage extension changes data/root.');
assert(c.seed~=c.calibrationSeed&&c.seed~=c.detectorSeed,'Development/evaluation seed overlap.');
assert(min(c.lambdaCandidatesTV)<1e-4&&max(c.lambdaCandidatesQ)>1,'Calibration range not extended.');
assert(numel(revision_methods())==5,'All five methods must run in all cells.');
[lam,idx,b]=revision_choose_lambda([.01 .1 1],[3 1 2]);assert(lam==.1&&idx==2&&b);
[~,~,b]=revision_choose_lambda([.01 .1 1],[1 2 3]);assert(~b,'Boundary incorrectly accepted.');
[~,~,b]=revision_choose_lambda([.01 .1 1],[Inf 1 2]);assert(~b,'Unfinished lower candidate counted as a bracket.');
assert(revision_gain_category(.018,.044,.08,.04)==4);
assert(revision_gain_category(.018,.044,.08,.05)==1);
assert(revision_gain_category(.10,.05,.10,.05)==3);
assert(revision_gain_category(.10,.01,.10,.05)==2);
report=struct('passed',true,'fullGridMethods',5,'stage1Fits',13*5*5,'stage2Fits',13*10*5);
fprintf('Protocol tests passed: selection, thresholds and full-grid scheduling.\n');
end

﻿# Born Revision MATLAB 

Self-contained MATLAB package for a fresh, matched-prior revision study.
Core study requires no additional MATLAB toolbox, Python, GPU or internet access.


## Run the recommended study

1. Extract the ZIP into a NEW folder, for example `C:\MATLAB\Born_Revision `.
2. In MATLAB set Current Folder to that extracted package folder. Close any old
   editor scripts with the same entry-point name to avoid launching another version.
3. Run:

```matlab
addpath(pwd,'-begin');
which revision_core -all
Run_Stronger_Study
```

The `which` output must list this package first. The script does not clear your
MATLAB path. It clears workspace variables, runs numerical/protocol regression
checks, calibrates, develops the detector, and evaluates all five methods.
The fixed main design has 12 grid cells plus one layered condition, ten paired
scenes per condition, and five methods: **650 evaluation reconstructions**.
The output folder is `results_stage1_v104` (the name also supports stage1-to-stage2
resumption; the main script requests all ten trials immediately).

Run the same script again after interruption. Completed checkpoints are reused.
A recorded failure is retained for audit, not silently deleted/replaced. Any
changed source or scientific configuration requires a new output root. This
prevents mixing different experiments. Preserve error logs and partial results.

## What happens before evaluation

- Self-tests: FFT/dense field agreement, exact Jacobian, priors, GMRES fallback,
  zero-contrast limit, detector bookkeeping, bounds, objective descent, the two
  original failed fixtures (12 and 13, each from saved and zero starts), and
  the new held-out training-mask regression.
- Quadratic candidates: `1e-4, 1e-3, 1e-2, 1e-1, 1, 10, 100`.
- TV candidates: `1e-7, 1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1`.
- Two independent regularization-development scenes and reciprocal channel
  groups for train/validation splitting. Neither scene is an evaluation scene.
- Q is selected first using pooled linear/nonlinear held-out full-forward error.
  TV is then selected using the LOCKED Q initializer for nonlinear TV, matching
  the initialization used in evaluation. Each prior has one shared lambda across
  its linear and nonlinear methods. No true-image score selects lambda.
- Development budgets: 400 outer iterations and 600 PCG iterations. Unfinished
  calibration fits are retried from the original initializer at 800 outer
  iterations, using a prespecified rule. Every attempt is preserved. Only fully
  converged finite candidates are eligible.
- The selected value for EACH prior must have an eligible converged candidate
  below and above it. This is a discrete-grid bracketing check, not proof of a
  continuous optimum. The default stops BEFORE detector/evaluation if it fails.
- Twelve independent labelled detector-development scenes, all five methods,
  thresholds 0.10/0.20/0.35/0.50, and largest-component versus all-component
  rules. One equally weighted rule is locked for all evaluation methods. All
  detector-development fits must converge; no evaluation-mask tuning is allowed.

If a development gate stops, do not bypass it merely to obtain a preferred
comparison. Upload the automatically saved `review_only/development_diagnostics.zip`.
The scores and failure histories identify whether the tested range or solver
budget needs a further, development-only protocol amendment. An edge optimum is
an informative outcome, not a software promise that an interior optimum exists.

## Optional separate phases

```matlab
run_revision('development'); % full-size calibration + detector only
run_revision('stage1');      % first five trials, 325 fits
run_revision('stage2');      % uniform extension to ten; reuses those five
```

These three modes share the same full-size scientific protocol and root.
Do not inspect five-trial results to choose favourable cells for extension.
The recommended `Run_Stronger_Study` commits to ten trials from the start.

`run_revision('pilot')` is a 24 x 24, 12-sensor, three-condition workflow check
in a separate folder. Pilot calibration may hit a boundary; pilot results must
not be pooled with the paper-scale study. A quick numerical smoke check without
calibration is:

```matlab
selftest_revision;
selftest_saved_cases;
selftest_protocol;
```

## Optional fresh-process Windows memory benchmark

After the main study completes, run:

```matlab
c = revision_config('stage2');
benchmark_revision_memory(c.outputRoot);
```

This launches 20 fresh MATLAB processes sequentially: all five methods on trial 1
of conditions 1, 4, 12 and 13. It requires Windows PowerShell and a MATLAB licence
that permits the child process. The main numerical study does not require this
benchmark. Local script-execution policy must permit the PowerShell sampler;
the package does not change that policy. A child log is retained for each run.

An external PowerShell observer samples the actual MATLAB process working set
at a target interval of 20 ms while the inversion pipeline is active. Required
Born initialization is included. The baseline is recorded after loading data
and constructing operators. Outputs include sampled active-process maximum,
baseline, descriptive difference, sample count and process-lifetime peak.

These are comparable process measurements, NOT exact solver allocation peaks.
They include MATLAB/allocator overhead and can miss short transients. Startup
is excluded from active sampling but included in the separately labelled
lifetime high-water mark. Missing samples are NaN. The benchmark's cold-process
timing is separate from the primary repeated-study timings. No claim of measured
memory efficiency is justified until these outputs have been inspected.

## Results to upload

The main run creates `results_stage1_v104/revision_review_bundle_v104.zip`.
The optional memory benchmark refreshes that ZIP with its results. Upload this
ZIP, not only screenshots. It contains:

- exact protocol, effective settings and source snapshot;
- calibration scores, attempts, locked settings and detector development;
- all saved scene/solution records, including exceptions and nonconvergence;
- `planned_run_coverage.csv` and `completion_status.txt` (expected/present counts);
- `trial_metrics_primary.csv`, `trial_metrics_all_thresholds.csv`;
- `summary_intervals.csv`, `paired_differences.csv`, `paired_trial_effects.csv`;
- `matched_prior_category_sensitivity.csv` for every pair and all cutoffs;
- `regime_threshold_sensitivity.csv` for the original primary pipeline contrast;
- original MATLAB PNG figures, including matched-prior effect intervals and
  detector-threshold sensitivity;
- memory results if separately run.

`paired_differences.csv` uses comparison minus reference. The separate
`paired_trial_effects.csv` uses positive-improvement signs for Dice, full residual
and localization, and comparison-minus-reference for time. Read column names.
Categories: 1 neither, 2 data-only, 3 joint, 4 Dice-only. Residual cutoffs are
absolute normalized-residual gains, not relative percentage improvements.

To regenerate reports without reconstruction:

```matlab
c=revision_config('stage2');
revision_report(c.outputRoot);
revision_extended_report(c.outputRoot);
pack_revision_results(c.outputRoot);
```

The bundle builder does not publish code/data online or invent a licence/DOI.
After scientific checks and author approval, deposit an appropriately licensed
source package and data archive in your chosen public repositories.

## Scientific interpretation

All five methods see identical measurements and bounds. Model comparisons are
available under BOTH priors over the complete grid, and zero-start controls are
available everywhere. Independent fresh evaluation seeds prevent reuse of
previously inspected evaluation scenes. Evaluation allows 100 outer and 300 PCG
iterations, with the existing tolerances retained. Unfinished fits and failures
are counted, not silently removed; numerical means report available observations.
Bootstrap intervals are paired, exploratory and unadjusted for multiplicity.
Ten trials do not guarantee precise boundaries. This remains a synthetic real-
contrast 2-D scalar same-discretization experiment, not independent full-wave,
3-D, lossy-tissue or clinical validation. Stronger results are not guaranteed.

## Validation of this delivered package

MATLAB/Octave is unavailable in the preparation environment. All MATLAB files
were parsed with MISS_HIT targeting MATLAB R2020b. An independent Python/SciPy
implementation passes all four original saved-case numerical checks. That is
NOT execution of this MATLAB release. The expanded end-to-end workflow and the
PowerShell memory sampler require native verification on your machine. MATLAB
self-tests run before evaluation and will stop on a regression.


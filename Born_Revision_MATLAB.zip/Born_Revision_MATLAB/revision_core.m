function varargout=revision_core(action,varargin)
% Corrected 2-D scalar scattering, real contrast, exp(-i*w*t) convention.
% No toolbox required. Every source is also a receiver (reciprocal geometry).
switch action
 case 'operators', varargout={operators(varargin{:})};
 case 'forward', [varargout{1:nargout}]=forward(varargin{:});
 case 'invert', varargout={invert(varargin{:})};
 case 'scene', varargout={scene(varargin{:})};
 case 'metrics', varargout={metrics(varargin{:})};
 case 'prior', [varargout{1:nargout}]=prior(varargin{:});
 case 'apply', varargout={applyG(varargin{:})};
 case 'dense', varargout={denseG(varargin{:})};
 case 'memory', [varargout{1:nargout}]=processMemory();
 otherwise, error('Unknown action: %s',action);
end
end

function op=operators(c)
% Cell-centred grid. Equivalent-disk integrated self term; off-diagonal
% midpoint quadrature. Both interaction/observation include k0^2 exactly once.
op.Nx=c.Nx;op.Ny=c.Ny;op.N=c.Nx*c.Ny;
op.dx=c.Lx/c.Nx;op.dy=c.Ly/c.Ny;op.dA=op.dx*op.dy;
op.x=((0:c.Nx-1)+0.5)*op.dx-c.Lx/2;
op.y=((0:c.Ny-1)+0.5)*op.dy-c.Ly/2;
[op.X,op.Y]=meshgrid(op.x,op.y);op.k=2*pi*c.frequency/c.c0;
a=sqrt(op.dA/pi);
self=1i*pi*op.k*a/2*besselh(1,1,op.k*a)-1;
[xx,yy]=meshgrid(-(c.Nx-1):c.Nx-1,-(c.Ny-1):c.Ny-1);
r=hypot(xx*op.dx,yy*op.dy);r(r==0)=a;
K=op.k^2*op.dA*1i/4*besselh(0,1,op.k*r);
K(c.Ny,c.Nx)=self;
embed=zeros(2*c.Ny,2*c.Nx);
embed(mod(-(c.Ny-1):c.Ny-1,2*c.Ny)+1, ...
      mod(-(c.Nx-1):c.Nx-1,2*c.Nx)+1)=K;
op.kernelFFT=fft2(embed);op.absKernelFFT=fft2(abs(embed));op.self=self;
th=(0:c.nSensors-1)'*2*pi/c.nSensors;
op.sensorXY=c.arrayRadius*[cos(th) sin(th)];
r=hypot(op.X(:)-op.sensorXY(:,1).',op.Y(:)-op.sensorXY(:,2).');
op.Uinc=1i/4*besselh(0,1,op.k*r);
op.R=op.k^2*op.dA*op.Uinc.'; % non-conjugate transpose
op.A=zeros(c.nSensors^2,op.N);
for t=1:c.nSensors
 idx=(t-1)*c.nSensors+(1:c.nSensors);
 op.A(idx,:)=op.R.*op.Uinc(:,t).';
end
% Correct column-major derivatives: y index varies fastest.
[DX,DY]=differences(c.Nx,c.Ny);
% Derivatives with respect to domain-normalised coordinates.
op.Dx=DX*c.Nx;op.Dy=DY*c.Ny;
op.Dx2=op.Dx.^2;op.Dy2=op.Dy.^2;
op.nData=c.nSensors^2;
w=whos('op');op.storedBytes=w.bytes;
end

function [Dx,Dy]=differences(nx,ny)
N=nx*ny; ids=reshape(1:N,ny,nx);
a=ids(:,1:end-1);b=ids(:,2:end);a=a(:);b=b(:);
Dx=sparse([a;a],[a;b],[-ones(size(a));ones(size(a))],N,N);
a=ids(1:end-1,:);b=ids(2:end,:);a=a(:);b=b(:);
Dy=sparse([a;a],[a;b],[-ones(size(a));ones(size(a))],N,N);
end

function z=applyG(op,v)
% Zero-padded convolution is the exact discrete off-diagonal matrix product.
n=size(v,2);p=zeros(2*op.Ny,2*op.Nx,n,'like',v+1i);
p(1:op.Ny,1:op.Nx,:)=reshape(v,op.Ny,op.Nx,n);
p=ifft2(fft2(p).*op.kernelFFT);
z=reshape(p(1:op.Ny,1:op.Nx,:),op.N,n);
end

function G=denseG(op)
r=hypot(op.X(:)-op.X(:).',op.Y(:)-op.Y(:).');
r(1:op.N+1:end)=sqrt(op.dA/pi);
G=op.k^2*op.dA*1i/4*besselh(0,1,op.k*r);
G(1:op.N+1:end)=op.self;
end

function [y,J,meta,U]=forward(x,op,c,needJ)
if nargin<4,needJ=false;end
x=x(:);rhs=op.Uinc;
% A rigorous row-sum bound determines whether fixed-point iteration is safe.
p=zeros(2*op.Ny,2*op.Nx);p(1:op.Ny,1:op.Nx)=reshape(abs(x),op.Ny,op.Nx);
p=real(ifft2(fft2(p).*op.absKernelFFT));
p=p(1:op.Ny,1:op.Nx);rho=max(p(:));
U=rhs;it=0;method='fixed_point';ok=false;
if rho<0.85
 for it=1:c.fieldMaxIterations
  V=rhs+applyG(op,x.*U);
  rr=V-U; U=V;
  if max(sqrt(sum(abs(rr).^2,1))./sqrt(sum(abs(rhs).^2,1)))<c.fieldTolerance
   ok=true;break;
  end
 end
end
if ~ok
 method='gmres';Af=@(v) v-applyG(op,x.*v);
 pre=@(v) v./(1-op.self*x);
 for t=1:size(rhs,2)
  [U(:,t),flag,~,its]=gmres(Af,rhs(:,t),c.gmresRestart, ...
    c.fieldTolerance,c.gmresCycles,pre,[],rhs(:,t));
  if flag~=0,error('Forward GMRES did not converge (source %d, flag %d).',t,flag);end
  it=max(it,(its(1)-1)*c.gmresRestart+its(2));
 end
end
rr=U-applyG(op,x.*U)-rhs;
rel=max(sqrt(sum(abs(rr).^2,1))./sqrt(sum(abs(rhs).^2,1)));
if rel>20*c.fieldTolerance,error('Field-equation residual too large: %.3g',rel);end
y=reshape(op.R*(x.*U),[],1);
J=[];
if needJ
 % Discrete reciprocity: R*(I-DG)^-1 = k^2*dA*U_rx^T.
 % Tx and Rx positions coincide, so receiver fields equal the computed U.
 J=zeros(op.nData,op.N);
 for t=1:size(U,2)
  idx=(t-1)*size(U,2)+(1:size(U,2));
  J(idx,:)=op.k^2*op.dA*(U.'.*U(:,t).');
 end
end
meta=struct('relativeResidual',rel,'rowSumBound',rho,'iterations',it,'method',method);
end

function [v,g,H,hd]=prior(x,op,kind,c)
N=numel(x);
if strcmp(kind,'quadratic')
 v=0.5*sum(x.^2)/N;g=x/N;H=@(p) p/N;hd=ones(N,1)/N;
elseif strcmp(kind,'tv')
 gx=op.Dx*x;gy=op.Dy*x;w=1./sqrt(gx.^2+gy.^2+c.tvEpsilon^2);
 v=mean(1./w-c.tvEpsilon);
 g=(op.Dx'*(w.*gx)+op.Dy'*(w.*gy))/N;
 % Positive lagged-diffusivity curvature; actual TV gradient/objective used.
 H=@(p) (op.Dx'*(w.*(op.Dx*p))+op.Dy'*(w.*(op.Dy*p)))/N;
 hd=(op.Dx2'*w+op.Dy2'*w)/N;
else,error('Unknown prior.');end
end

function s=invert(y,op,c,model,kind,lambda,x0,trainMask)
% min .5*||F(x)-y||^2/||y||^2 + lambda*R(x), real bounded x.
% Both methods use identical coordinates, penalty definitions and constraints.
if nargin<8 || isempty(trainMask),trainMask=true(size(y));end
assert(numel(trainMask)==numel(y)&&any(trainMask),'Invalid training-channel mask.');
trainMask=logical(trainMask(:));x=min(max(real(x0(:)),c.lowerBound),c.upperBound);
scale=max(norm(y(trainMask)),1e-14);yc=y(trainMask)/scale;
ticSolve=tic;[mem0,memKind]=processMemory();memMax=mem0;
status='iteration_limit';fc=0;pcgFailures=0;fallbackSteps=0;
history=zeros(c.maxIterations+1,9); % iter, objective, misfit, penalty, PG, update, step, PCGflag, fieldResidual
if strcmp(model,'linear'),yp=op.A*x;Jfull=op.A;fr=0;
else,[yp,Jfull,meta]=forward(x,op,c,true);fr=meta.relativeResidual;fc=fc+1;end
pg0=[];lastRelObj=Inf;lastUpdate=Inf;
for k=0:c.maxIterations
 J=Jfull(trainMask,:)/scale;r=yp(trainMask)/scale-yc;
 [pen,gp,Hp,hd]=prior(x,op,kind,c);
 obj=0.5*real(r'*r)+lambda*pen;
 g=real(J'*r)+lambda*gp;
 pg=x-min(max(x-g,c.lowerBound),c.upperBound);
 pgn=norm(pg,Inf);if isempty(pg0),pg0=max(pgn,1e-12);end
 history(k+1,1:5)=[k obj norm(r) pen pgn];
 history(k+1,9)=fr;
 [mm,~]=processMemory();memMax=maxFinite(memMax,mm);
 if pgn<=c.gradientTolerance*max(1,pg0)
  status='projected_gradient';break;
 end
 if k>1 && lastRelObj<c.objectiveTolerance && lastUpdate<c.updateTolerance
  status='objective_and_update';break;
 end
 if k==c.maxIterations,break;end
 diagData=sum(abs(J).^2,1).';damp=1e-8*max(max(diagData+lambda*hd),1);
 Hv=@(v) real(J'*(J*v))+lambda*Hp(v)+damp*v;
 pre=max(diagData+lambda*hd+damp,1e-12);
 % Hold binding bounds fixed in the Newton system. A full-space Newton
 % direction need not remain a descent direction after projection.
 free=~((x<=c.lowerBound & g>0)|(x>=c.upperBound & g<0));
 maskedH=@(v) free.*Hv(free.*v)+(~free).*v;
 [p,flag]=pcg(maskedH,-free.*g,c.pcgTolerance,c.pcgMaxIterations, ...
  @(v) v./(free.*pre+(~free)));
 p=free.*p;
 if flag~=0,pcgFailures=pcgFailures+1;end
 if any(~isfinite(p)) || g'*p>=0,p=-g./pre;end
 accepted=false;
 % Retry failed projected Newton searches with a diagonally scaled
 % projected-gradient direction. Check descent AFTER applying the bounds.
 for attempt=1:2
  if attempt==2,p=-g./pre;fallbackSteps=fallbackSteps+1;end
  alpha=1;
  for ls=1:c.maxLineSearch
   xt=min(max(x+alpha*p,c.lowerBound),c.upperBound);dx=xt-x;
   if g'*dx>=0,alpha=alpha/2;continue;end
   if strcmp(model,'linear'),yt=op.A*xt;frt=0;
   else,[yt,~,mt]=forward(xt,op,c,false);frt=mt.relativeResidual;fc=fc+1;end
   pt=prior(xt,op,kind,c);rt=(yt(trainMask)-y(trainMask))/scale;
   ot=0.5*real(rt'*rt)+lambda*pt;
   if ot<=obj+1e-4*(g'*dx),accepted=true;break;end
   alpha=alpha/2;
  end
  if accepted,break;end
 end
 if ~accepted,status='line_search_failed';break;end
 lastUpdate=norm(dx)/max(norm(x),1e-12);
 lastRelObj=abs(obj-ot)/max(abs(obj),1e-12);
 history(k+2,6:8)=[lastUpdate alpha flag];
 x=xt;yp=yt;fr=frt;
 if ~strcmp(model,'linear')
  [yp,Jfull,meta]=forward(x,op,c,true);fr=meta.relativeResidual;fc=fc+1;
 end
end
s=struct('x',x,'nativePrediction',yp,'model',model,'prior',kind,'lambda',lambda, ...
 'status',status,'iterations',k,'history',history(1:k+1,:), ...
 'projectedGradientFallbacks',fallbackSteps, ...
 'seconds',toc(ticSolve),'forwardCalls',fc,'pcgNonzeroFlags',pcgFailures, ...
 'memoryStartMiB',mem0,'sampledMemoryMaxMiB',memMax, ...
 'memoryMeasurement',memKind,'initialNorm',norm(x0),'dataScale',scale,'trainingMask',trainMask,'trainingChannels',nnz(trainMask));
s.converged=ismember(status,{'projected_gradient','objective_and_update'});
w=whos('J','Jfull','history','x','yp','pre');s.visibleSolverArrayMiB=sum([w.bytes])/2^20;
end

function z=maxFinite(a,b)
if isnan(a),z=b;elseif isnan(b),z=a;else,z=max(a,b);end
end

function [m,kind]=processMemory()
% Sampled process memory is not a per-solve peak allocation measurement.
m=NaN;kind='unavailable';
try
 if ispc
  u=memory;m=u.MemUsedMATLAB/2^20;kind='Windows MemUsedMATLAB sampled';
 elseif isunix && exist('/proc/self/status','file')
  t=fileread('/proc/self/status');a=regexp(t,'VmRSS:\s+(\d+)\s+kB','tokens','once');
  if ~isempty(a),m=str2double(a{1})/1024;kind='Linux process RSS sampled';end
 end
catch
end
end

function d=scene(op,c,cond,trial,isDevelopment)
if nargin<5,isDevelopment=false;end
seed=c.seed+10000*double(isDevelopment)+100*cond.id+trial;
rng(seed,'twister');state=rng;
% Correlation kernel specified in metres; symmetric boundary padding without toolbox.
sigma=0.0075;rx=ceil(3*sigma/op.dx);ry=ceil(3*sigma/op.dy);
[kx,ky]=meshgrid(-rx:rx,-ry:ry);ker=exp(-0.5*((kx*op.dx).^2+(ky*op.dy).^2)/sigma^2);ker=ker/sum(ker(:));
w=randn(op.Ny,op.Nx);ip=reflectIndices(op.Ny,ry);jp=reflectIndices(op.Nx,rx);
bg=conv2(w(ip,jp),ker,'valid');bg=bg-mean(bg(:));bg=bg/std(bg(:),0);
if strcmp(cond.background,'layered')
 % Two interfaces with random orientation and offset, plus correlated variation.
 theta=(rand-0.5)*pi/8;offset=(rand-0.5)*0.01;
 coord=op.Y*cos(theta)+op.X*sin(theta)-offset;
 layers=double(coord>-.025)-double(coord>.025);
 layers=layers-mean(layers(:));layers=layers/max(std(layers(:)),eps);
 bg=0.35*bg+layers;bg=bg-mean(bg(:));bg=bg/std(bg(:),0);
end
bg=cond.h*bg;center=[-.02+.04*rand,0.02];
mask=(op.X-center(1)).^2+(op.Y-center(2)).^2<=c.targetRadius^2;
target=cond.contrast*double(mask);truth=bg+target;
% Never clip the truth silently. A failed bound check remains a recorded failure.
assert(all(truth(:)>=c.lowerBound & truth(:)<=c.upperBound),'Generated truth exceeds declared inversion bounds.');
[clean,~,meta]=forward(truth(:),op,c,false);
sigmaNoise=norm(clean)/sqrt(numel(clean))*10^(-c.noiseSNRdB/20);
noise=sigmaNoise/sqrt(2)*(randn(size(clean))+1i*randn(size(clean)));
y=clean+noise;linear=op.A*truth(:);
d=struct('truth',truth(:),'backgroundTruth',bg(:),'targetTruth',target(:), ...
 'targetMask',mask,'yClean',clean,'y',y,'noise',noise,'rngState',state, ...
 'seed',seed,'center',center,'condition',cond,'trial',trial,'development',isDevelopment, ...
 'noiseSigma',sigmaNoise,'realizedNoiseRatio',norm(noise)/norm(clean), ...
 'forwardBornDiscrepancy',norm(clean-linear)/max(norm(clean),eps), ...
 'fieldDiagnostic',meta,'backgroundKernelSigmaMetres',sigma);
end

function ind=reflectIndices(n,r)
k=(1-r:n+r)-1;k=mod(k,2*n);ind=1+min(k,2*n-1-k);
end

function m=metrics(x,d,op,threshold,rule)
if nargin<5,rule='largest';end
assert(ismember(rule,{'largest','all'}),'Unknown detector rule.');
% Total contrast magnitude threshold, largest 8-connected component.
% Endpoint detects target amid unknown background; not target-excess imaging.
a=reshape(abs(x),op.Ny,op.Nx);mask=a>threshold*max(a(:));
if strcmp(rule,'largest'),mask=largestComponent(mask);end
truth=logical(d.targetMask);
tp=nnz(mask&truth);fp=nnz(mask&~truth);fn=nnz(~mask&truth);tn=nnz(~mask&~truth);
if nnz(mask)==0,loc=NaN;fdp=NaN;prec=NaN;
else
 loc=hypot(mean(op.X(mask))-mean(op.X(truth)),mean(op.Y(mask))-mean(op.Y(truth)));
 fdp=fp/(tp+fp);prec=1-fdp;
end
m=struct('threshold',threshold,'Dice',2*tp/max(2*tp+fp+fn,1), ...
 'IoU',tp/max(tp+fp+fn,1),'Localization_m',loc, ...
 'ContrastError',norm(x-d.truth)/max(norm(d.truth),eps), ...
 'FDP',fdp,'FPR',fp/max(fp+tn,1),'Precision',prec,'Recall',tp/max(tp+fn,1), ...
 'EmptySupport',nnz(mask)==0,'TP',tp,'FP',fp,'FN',fn,'TN',tn,'support',mask);
end

function best=largestComponent(mask)
[ny,nx]=size(mask);seen=false(ny,nx);best=false(ny,nx);nb=0;
queue=zeros(numel(mask),1);component=queue;
for seed=find(mask(:)).'
 if seen(seed),continue;end
 head=1;tail=1;queue(1)=seed;seen(seed)=true;n=0;
 while head<=tail
  z=queue(head);head=head+1;n=n+1;component(n)=z;[r,c]=ind2sub([ny nx],z);
  for rr=max(1,r-1):min(ny,r+1)
   for cc=max(1,c-1):min(nx,c+1)
    j=rr+(cc-1)*ny;
    if mask(j)&&~seen(j),seen(j)=true;tail=tail+1;queue(tail)=j;end
   end
  end
 end
 if n>nb,best(:)=false;best(component(1:n))=true;nb=n;end
end
end


function report=selftest_saved_cases()
% Regression fixtures are the user's actual BR-1.0.1 failed Born_Q cases.
% Run with original data, operators, lambda, bounds and iteration limit.
root=fileparts(mfilename('fullpath'));
f=fullfile(root,'regression_fixtures');tmp=load(fullfile(f,'operators.mat'),'op');op=tmp.op;
c=revision_config('pilot');records=struct([]);
for id=[12 13]
 tmp=load(fullfile(f,sprintf('condition_%02d_trial_001.mat',id)),'payload');
 d=tmp.payload.data;old=tmp.payload.solutions.Born_Q.solver;
 assert(strcmp(old.status,'line_search_failed'),'Unexpected regression fixture.');
 for start={'saved','zero'}
  if strcmp(start{1},'saved'),x0=old.x;else,x0=zeros(op.N,1);end
  s=revision_core('invert',d.y,op,c,'linear','quadratic',old.lambda,x0);
  % Require stationarity, not merely a small objective/update stopping test.
  assert(strcmp(s.status,'projected_gradient'),'Case %d (%s): %s',id,start{1},s.status);
  assert(s.history(end,5)<=c.gradientTolerance*max(1,s.history(1,5)), ...
   'Projected-gradient tolerance not met.');
  assert(all(diff(s.history(:,2))<=1e-12),'Objective increased.');
  assert(all(s.x>=c.lowerBound & s.x<=c.upperBound),'Bounds violated.');
  assert(s.history(end,2)<old.history(end,2)-1e-10,'Failed objective not improved.');
  rec=struct('Condition',id,'Start',start{1},'Iterations',s.iterations, ...
   'FinalProjectedGradient',s.history(end,5),'OldObjective',old.history(end,2), ...
   'NewObjective',s.history(end,2),'FallbackAttempts',s.projectedGradientFallbacks, ...
   'Passed',true);
  records=revision_append_record(records,rec);
 end
end
report=struct2table(records);disp(report);
fprintf('All four saved-case regression checks passed.\n');
end


param([string]$MatlabExe,[string]$Package,[string]$InputFile,[string]$OutputFile,[string]$Marker,[string]$SampleFile)
$ErrorActionPreference = 'Stop'
function MQuote([string]$s) { return $s.Replace("'", "''") }
$expr = "addpath('$(MQuote $Package)');revision_memory_worker('$(MQuote $InputFile)','$(MQuote $OutputFile)','$(MQuote $Marker)');"
$log = $OutputFile + '.log'
$launch = Start-Process -FilePath $MatlabExe -ArgumentList @('-wait','-batch',('"' + $expr + '"'),'-logfile',('"' + $log + '"')) -PassThru
$samples = [System.Collections.Generic.List[object]]::new()
$clock = [System.Diagnostics.Stopwatch]::StartNew()
try {
 while (-not $launch.HasExited) {
  if ($clock.Elapsed.TotalHours -gt 2) { throw 'Memory benchmark exceeded two hours. Inspect child MATLAB log.' }
  if (Test-Path -LiteralPath $Marker) {
   try {
    $matlabProcessId = [int](Get-Content -LiteralPath $Marker -Raw)
    $targetProcess = [System.Diagnostics.Process]::GetProcessById($matlabProcessId)
    $targetProcess.Refresh()
    $samples.Add([pscustomobject]@{Seconds=$clock.Elapsed.TotalSeconds;WorkingSetMiB=$targetProcess.WorkingSet64/1MB})
   } catch { } # Marker can disappear between test and read.
  }
  Start-Sleep -Milliseconds 20
  $launch.Refresh()
 }
 if ($launch.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $OutputFile)) { throw "MATLAB benchmark failed. See $log" }
 if ($samples.Count -gt 0) { $samples | Export-Csv -LiteralPath $SampleFile -NoTypeInformation }
 else { 'Seconds,WorkingSetMiB' | Set-Content -LiteralPath $SampleFile }
} catch {
 Write-Error $_
 exit 1
}

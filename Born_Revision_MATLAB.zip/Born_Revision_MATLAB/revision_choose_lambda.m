function [lambda,index,bracketed]=revision_choose_lambda(candidates,scores)
assert(isvector(candidates)&&all(isfinite(candidates))&&all(candidates>0)&&all(diff(candidates)>0), ...
 'Lambda grid must be finite, positive and strictly increasing.');
assert(numel(candidates)==numel(scores),'Candidate/score size mismatch.');
[best,index]=min(scores);
assert(isfinite(best),'No fully converged calibration candidate. Inspect saved development scores.');
lambda=candidates(index);
bracketed=any(isfinite(scores(1:index-1)))&&any(isfinite(scores(index+1:end)));
end

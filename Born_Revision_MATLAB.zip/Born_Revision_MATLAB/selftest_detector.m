function selftest_detector()
% Verify topology option and prespecified selection/tie-breaking.
op=struct('Ny',3,'Nx',3);[op.X,op.Y]=meshgrid(1:3);
x=zeros(9,1);x([1 9])=1;d=struct('targetMask',reshape(x>0,3,3),'truth',x);
a=revision_core('metrics',x,d,op,.1,'all');b=revision_core('metrics',x,d,op,.1,'largest');
assert(a.Dice==1 && nnz(a.support)==2 && nnz(b.support)==1,'Component options failed.');
rows=struct([]);
for rule={'largest','all'}
 for threshold=[.1 .2 .35 .5]
  dice=.2;fpr=.3;
  if threshold==.35,dice=.8;end
  if strcmp(rule{1},'all'),fpr=.1;end
  rows=revision_append_record(rows,struct('Scene',1,'Method','fixture','Rule',rule{1}, ...
   'Threshold',threshold,'Dice',dice,'FPR',fpr));
 end
end
[d,~]=revision_select_detector(struct2table(rows));
assert(strcmp(d.rule,'all') && d.threshold==.35,'Selection/tie-break failed.');
fprintf('Detector component and selection tests passed.\n');
end


function revision_report(root)
% Regenerate tables/figures from checkpoints; never re-runs reconstruction.
q=load(fullfile(root,'protocol.mat'),'protocol');c=q.protocol;
if exist(fullfile(root,'effective_config.mat'),'file'),econf=load(fullfile(root,'effective_config.mat'),'c');c=econf.c;end
q=load(fullfile(root,'operators.mat'),'op');op=q.op;
writeProtocolTables(root,c);
files=dir(fullfile(root,'cases','condition_*.mat'));
rows=struct([]);scenes=struct([]);nr=0;ns=0;failedScenes=0;
for fi=1:numel(files)
 q=load(fullfile(files(fi).folder,files(fi).name),'payload');p=q.payload;
 if ~p.sceneSuccess,failedScenes=failedScenes+1;continue;end
 ns=ns+1;scenes=revision_append_record(scenes,struct('Condition',p.condition.id,'Trial',p.trial, ...
  'Heterogeneity',p.condition.h,'Contrast',p.condition.contrast, ...
  'Background',p.condition.background,'BornForwardDiscrepancy',p.data.forwardBornDiscrepancy, ...
  'RealizedNoiseRatio',p.data.realizedNoiseRatio,'Seed',p.data.seed)); %#ok<AGROW>
 methods=fieldnames(p.solutions);
 for mi=1:numel(methods)
  name=methods{mi};e=p.solutions.(name);
  for ti=1:numel(c.thresholds)
   r=blankRow();r.Condition=p.condition.id;r.Trial=p.trial;r.Method=name;
   r.Background=p.condition.background;r.Heterogeneity=p.condition.h;r.Contrast=p.condition.contrast;
   r.Threshold=c.thresholds(ti);r.Success=e.success;
   if e.success
    m=e.metrics{ti};s=e.solver;
    names={'Dice','IoU','Localization_m','ContrastError','FDP','FPR','Precision','Recall','EmptySupport','TP','FP','FN','TN'};
    for z=1:numel(names),r.(names{z})=double(m.(names{z}));end
    r.NativeMisfit=e.nativeMisfit;r.FullMisfit=e.fullMisfit;
    r.SolverSeconds=s.seconds;r.PipelineSeconds=e.pipelineSeconds;r.EvaluationSeconds=e.evaluationSeconds;
    r.Iterations=s.iterations;r.Converged=s.converged;r.Stop=s.status;r.Lambda=s.lambda;
    r.SampledMemoryMaxMiB=s.sampledMemoryMaxMiB;r.MemoryStartMiB=s.memoryStartMiB;
    r.VisibleSolverArrayMiB=s.visibleSolverArrayMiB;r.MemoryMeasurement=s.memoryMeasurement;
    r.ForwardCalls=s.forwardCalls;r.PCGNonzeroFlags=s.pcgNonzeroFlags;
   else,r.Stop='exception';r.Error=e.error;end
   nr=nr+1;rows=revision_append_record(rows,r); %#ok<AGROW>
  end
 end
end
assert(nr>0,'No reconstruction records available.');T=struct2table(rows);
writetable(T,fullfile(root,'trial_metrics_all_thresholds.csv'));
S=struct2table(scenes);writetable(S,fullfile(root,'scene_diagnostics.csv'));
P=T(T.Threshold==c.primaryThreshold,:);writetable(P,fullfile(root,'trial_metrics_primary.csv'));
% Descriptive summaries; failures, empty support and non-convergence counted.
metrics={'Dice','IoU','FullMisfit','NativeMisfit','ContrastError','Localization_m','FDP','FPR','SolverSeconds','PipelineSeconds','SampledMemoryMaxMiB'};
summary=struct([]);n=0;
conds=unique(T.Condition).';methods=unique(T.Method,'stable');
rng(c.seed+600000,'twister'); % deterministic report-only bootstrap
for id=conds
 for mi=1:numel(methods)
  for threshold=c.thresholds
   A=T(T.Condition==id & strcmp(T.Method,methods{mi}) & T.Threshold==threshold,:);
   if isempty(A),continue;end
   for z=1:numel(metrics)
    v=A.(metrics{z});valid=A.Success & isfinite(v);[avg,lo,hi]=interval(v(valid),c.bootstrapSamples);
    n=n+1;summary=revision_append_record(summary,struct('Condition',id,'Method',methods{mi},'Threshold',threshold, ...
     'Metric',metrics{z},'Attempted',height(A),'Successful',nnz(A.Success), ...
     'Converged',nnz(A.Converged),'EmptySupports',sum(A.EmptySupport==1), ...
     'NValid',nnz(valid),'Mean',avg,'Lower95',lo,'Upper95',hi, ...
     'ExploratorySmallSample',nnz(valid)<10)); %#ok<AGROW>
   end
  end
 end
end
U=struct2table(summary);writetable(U,fullfile(root,'summary_intervals.csv'));
% Paired differences, never differences between unpaired marginal CIs.
pairs={'Born_Q','NL_TV_BornQ';'Born_Q','NL_Q_BornQ'; ...
       'Born_TV','NL_TV_BornQ';'NL_TV_BornQ','NL_TV_Zero'};
pairMetrics={'Dice','FullMisfit','ContrastError','Localization_m','PipelineSeconds'};
paired=struct([]);n=0;regimes=struct([]);ng=0;
for id=conds
 for pi=1:size(pairs,1)
  for threshold=c.thresholds
   A=T(T.Condition==id & strcmp(T.Method,pairs{pi,1}) & T.Threshold==threshold,:);
   B=T(T.Condition==id & strcmp(T.Method,pairs{pi,2}) & T.Threshold==threshold,:);
   [~,ia,ib]=intersect(A.Trial,B.Trial);A=A(ia,:);B=B(ib,:);
   if isempty(A),continue;end
   for z=1:numel(pairMetrics)
    met=pairMetrics{z};valid=A.Success&B.Success&isfinite(A.(met))&isfinite(B.(met));
    delta=B.(met)(valid)-A.(met)(valid);
    [avg,lo,hi]=interval(delta,c.bootstrapSamples);
    n=n+1;paired=revision_append_record(paired,struct('Condition',id,'Reference',pairs{pi,1},'Comparison',pairs{pi,2}, ...
     'Threshold',threshold,'Metric',met,'AvailablePairs',height(A),'ValidPairs',nnz(valid), ...
     'BothConverged',nnz(valid&A.Converged&B.Converged),'Mean_B_minus_A',avg, ...
     'Lower95',lo,'Upper95',hi,'ExploratorySmallSample',nnz(valid)<10)); %#ok<AGROW>
   end
   if pi==1
    v=A.Success&B.Success;dd=B.Dice(v)-A.Dice(v);dm=A.FullMisfit(v)-B.FullMisfit(v);
    if isempty(dd),continue;end
    idx=randi(numel(dd),numel(dd),c.bootstrapSamples);
    bd=mean(dd(idx),1);bm=mean(dm(idx),1);
    for tm=c.misfitCutoffs
     for td=c.diceCutoffs
      code=category(mean(dm),mean(dd),tm,td);bc=category(bm,bd,tm,td);
      ng=ng+1;regimes=revision_append_record(regimes,struct('Condition',id,'SupportThreshold',threshold, ...
       'MisfitCutoff',tm,'DiceCutoff',td,'NPaired',numel(dd),'MeanMisfitGain',mean(dm), ...
       'MeanDiceGain',mean(dd),'Code',code,'BootstrapFractionSameCode',mean(bc==code), ...
       'FractionNeither',mean(bc==1),'FractionDataOnly',mean(bc==2), ...
       'FractionJoint',mean(bc==3),'FractionDiceOnly',mean(bc==4))); %#ok<AGROW>
     end
    end
   end
  end
 end
end
if ~isempty(paired),writetable(struct2table(paired),fullfile(root,'paired_differences.csv'));end
if ~isempty(regimes),writetable(struct2table(regimes),fullfile(root,'regime_threshold_sensitivity.csv'));end
save(fullfile(root,'analysis_tables.mat'),'T','P','S','U','paired','regimes','-v7');
% Honest readiness report; no automatic claims of publishability.
fid=fopen(fullfile(root,'readiness.txt'),'w');assert(fid>=0);cl=onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'COMPUTATIONAL CHECKPOINT -- NOT AN ACCEPTANCE CERTIFICATE\n\n');
fprintf(fid,'Successful scene files: %d; failed scene files: %d\n',ns,failedScenes);
fprintf(fid,'Attempted reconstructions: %d; exceptions: %d\n',height(P),nnz(~P.Success));
fprintf(fid,'Successful solves not satisfying stopping criteria: %d\n',nnz(P.Success & ~P.Converged));
fprintf(fid,'Empty predicted supports: %d\n',sum(P.EmptySupport==1));
fprintf(fid,'Unknown real total contrast; no true background supplied to solvers.\n');
fprintf(fid,'Noise and discretisation are synthetic; this is not independent full-wave or 3D validation.\n');
fprintf(fid,'Primary support threshold %.2f; all alternative thresholds retained.\n',c.primaryThreshold);
fprintf(fid,'Bootstrap intervals are exploratory, especially with n=5. Degenerate intervals are not proof of certainty.\n');
fprintf(fid,'Non-converged successful reconstructions are retained in summaries and counted, not silently discarded.\n');
fprintf(fid,'Failed solves and undefined centroids/FDP are excluded only from the affected numerical mean; counts are reported.\n');
fprintf(fid,'Memory values are sampled process usage, not isolated solver peaks. Visible array sizes are partial accounting.\n');
fprintf(fid,'Inspect calibration boundary choices and calibration non-convergence before interpreting comparisons.\n\n');
fprintf(fid,'Stage2 rule: complete all conditions to ten paired trials if stage1 precision/convergence is inadequate.\n');
fprintf(fid,'Do not selectively repeat favourable conditions. Exploratory percentile intervals are not sequentially valid confidence sequences.\n');
fprintf(fid,'At ten trials, unresolved conditions remain unresolved unless a new prospectively specified study is run.\n');
fprintf(fid,'Screening flags below use half-width >0.05 for Dice or full-misfit differences; they are descriptive planning criteria.\n');
for k=1:numel(paired)
 r=paired(k);
 if r.Threshold==c.primaryThreshold && strcmp(r.Reference,'Born_Q') && strcmp(r.Comparison,'NL_TV_BornQ') && ismember(r.Metric,{'Dice','FullMisfit'})
  flag=r.ValidPairs<10 || r.BothConverged<r.ValidPairs || ~isfinite(r.Lower95) || (r.Upper95-r.Lower95)/2>0.05;
  fprintf(fid,'Condition %02d %s: valid n=%d; CI [%.4g %.4g]; needs review/extension=%d\n',r.Condition,r.Metric,r.ValidPairs,r.Lower95,r.Upper95,flag);
 end
end
makePlots=true;
if exist(fullfile(root,'last_run_config.mat'),'file')
 last=load(fullfile(root,'last_run_config.mat'),'c');makePlots=last.c.makeFigures;
end
if makePlots
 try,makeFigures(root,op,c,P,U,files,regimes);catch ME,warning('Tables saved, but figure generation failed: %s',ME.message);end
end
fprintf('Analysis saved: %d reconstruction records; %d paired summaries.\n',height(P),numel(paired));
end

function r=blankRow()
r=struct('Condition',0,'Trial',0,'Method','','Background','','Heterogeneity',NaN,'Contrast',NaN, ...
 'Threshold',NaN,'Success',false,'Converged',false,'Stop','','Error','','MemoryMeasurement','');
names={'Dice','IoU','Localization_m','ContrastError','FDP','FPR','Precision','Recall','EmptySupport', ...
 'TP','FP','FN','TN','NativeMisfit','FullMisfit','SolverSeconds','PipelineSeconds','EvaluationSeconds', ...
 'Iterations','Lambda','SampledMemoryMaxMiB','MemoryStartMiB','VisibleSolverArrayMiB','ForwardCalls','PCGNonzeroFlags'};
for k=1:numel(names),r.(names{k})=NaN;end
end

function [avg,lo,hi]=interval(v,B)
v=v(:);avg=NaN;lo=NaN;hi=NaN;if isempty(v),return;end
avg=mean(v);if numel(v)<2,return;end
idx=randi(numel(v),numel(v),B);b=sort(mean(v(idx),1));
lo=percentileSorted(b,.025);hi=percentileSorted(b,.975);
end
function v=percentileSorted(x,p)
f=1+(numel(x)-1)*p;l=floor(f);u=ceil(f);v=x(l)+(f-l)*(x(u)-x(l));
end
function code=category(dm,dd,tm,td)
code=ones(size(dm));code(dm>=tm & dd<td)=2;
code(dm>=tm & dd>=td)=3;code(dm<tm & dd>=td)=4;
end

function makeFigures(root,op,c,P,U,files,regimes)
folder=fullfile(root,'figures');if ~exist(folder,'dir'),mkdir(folder);end
f=figure('Visible','off','Color','w','Position',[100 100 650 550]);
plot(op.sensorXY(:,1),op.sensorXY(:,2),'o');hold on;
rectangle('Position',[-c.Lx/2 -c.Ly/2 c.Lx c.Ly]);
plot([0 c.arrayRadius],[0 0],'k--');text(c.arrayRadius/2,-.012,sprintf('R = %.2f m',c.arrayRadius));
text(-c.Lx/2,c.Ly/2+.015,sprintf('Domain %.2f x %.2f m',c.Lx,c.Ly));
text(-.075,-.065,{'Unknown heterogeneous background';'Target x in [-0.02, 0.02] m'},'FontSize',9);
rectangle('Position',[-c.targetRadius .02-c.targetRadius 2*c.targetRadius 2*c.targetRadius],'Curvature',[1 1]);
axis equal;grid on;xlabel('x (m)');ylabel('y (m)');title('Shared Tx/Rx array; example target at y = 0.02 m');
exportgraphics(f,fullfile(folder,'geometry.png'),'Resolution',180);close(f);
% Discrete map axes do not distort the nonuniform contrast spacing.
f=figure('Visible','off','Color','w','Position',[100 100 1150 650]);tiledlayout(2,3);
mapMethods={'Born_Q','NL_TV_BornQ'};mapMetrics={'Dice','FullMisfit'};
for z=1:4
 mi=1+mod(z-1,2);mt=1+floor((z-1)/2);mat=NaN(3,4);
 for id=1:12
  a=U(U.Condition==id & strcmp(U.Method,mapMethods{mi}) & strcmp(U.Metric,mapMetrics{mt}) & U.Threshold==c.primaryThreshold,:);
  if ~isempty(a),mat(ceil(id/4),1+mod(id-1,4))=a.Mean(1);end
 end
 nexttile;imagesc(mat);set(gca,'YDir','normal','XTick',1:4,'XTickLabel',c.contrasts,'YTick',1:3,'YTickLabel',c.heterogeneity);
 colorbar;xlabel('Target contrast');ylabel('Background SD');title([mapMethods{mi} ' ' mapMetrics{mt}],'Interpreter','none');
 if mt==1,caxis([0 1]);else,caxis([0 1.2]);end
end
mat=NaN(3,4);
for k=1:numel(regimes)
 r=regimes(k);
 if r.Condition<=12 && r.SupportThreshold==c.primaryThreshold && abs(r.MisfitCutoff-.10)<1e-10 && abs(r.DiceCutoff-.05)<1e-10
  mat(ceil(r.Condition/4),1+mod(r.Condition-1,4))=r.Code;
 end
end
nexttile;imagesc(mat,[.5 4.5]);set(gca,'YDir','normal','XTick',1:4,'XTickLabel',c.contrasts,'YTick',1:3,'YTickLabel',c.heterogeneity);
cb=colorbar;cb.Ticks=1:4;cb.TickLabels={'Neither','Data only','Joint','Dice only'};colormap(gca,lines(4));title('Descriptive gain categories');
nexttile;axis off;text(0,0.8,{'Means over available paired trials.';'Missing cells are untested.';'Categories do not establish physical validity.';'Read confidence intervals and failure counts.'},'FontSize',11);
exportgraphics(f,fullfile(folder,'operating_grid.png'),'Resolution',180);close(f);
% Every method's per-trial support scores are visible.
f=figure('Visible','off','Color','w','Position',[100 100 1200 450]);tiledlayout(1,3);
for z=1:3
 ids=[1 12 13];id=ids(z);nexttile;hold on;names=unique(P.Method(P.Condition==id),'stable');
 for k=1:numel(names)
  a=P(P.Condition==id & strcmp(P.Method,names{k}) & P.Success,:);
  scatter(k+linspace(-.12,.12,height(a))',a.Dice,25,'filled');
 end
 set(gca,'XTick',1:numel(names),'XTickLabel',names);xtickangle(35);ylim([0 1]);ylabel('Dice');title(sprintf('Condition %d: individual trials',id));grid on;
end
exportgraphics(f,fullfile(folder,'control_trial_dice.png'),'Resolution',180);close(f);
% Representative cases explicitly selected as trial 1, never best-performing.
for fi=1:numel(files)
 q=load(fullfile(files(fi).folder,files(fi).name),'payload');p=q.payload;
 if ~p.sceneSuccess || p.trial~=1,continue;end
 names=fieldnames(p.solutions);n=numel(names);
 f=figure('Visible','off','Color','w','Position',[50 50 1450 650]);tiledlayout(2,n+1);
 nexttile;imagesc(op.x,op.y,reshape(p.data.truth,op.Ny,op.Nx));axis image xy;colorbar;title('Truth');caxis([c.lowerBound c.upperBound]);
 for k=1:n
  nexttile;e=p.solutions.(names{k});
  if e.success
   imagesc(op.x,op.y,reshape(e.solver.x,op.Ny,op.Nx));axis image xy;caxis([c.lowerBound c.upperBound]);hold on;
   contour(op.x,op.y,double(p.data.targetMask),[.5 .5],'k');
   title(sprintf('%s\nDice %.3f',names{k},e.metrics{1}.Dice),'Interpreter','none');
  else,axis off;title([names{k} ' FAILED'],'Interpreter','none');end
 end
 nexttile;imagesc(op.x,op.y,p.data.targetMask);axis image xy;title('True target support');
 for k=1:n
  nexttile;e=p.solutions.(names{k});
  if e.success,imagesc(op.x,op.y,e.metrics{1}.support,[0 1]);axis image xy;title('Predicted support');else,axis off;end
 end
 exportgraphics(f,fullfile(folder,sprintf('condition_%02d_trial1_reconstruction.png',p.condition.id)),'Resolution',160);close(f);
 f=figure('Visible','off','Color','w','Position',[100 100 1100 400]);tiledlayout(1,2);
 for panel=1:2
  nexttile;hold on;
  for k=1:n
   e=p.solutions.(names{k});if ~e.success,continue;end
   h=e.solver.history;semilogy(h(:,1),max(h(:,panel+1),realmin),'-o','DisplayName',names{k});
  end
  set(gca,'YScale','log');xlabel('Accepted iteration (0 = initialization)');grid on;legend('Interpreter','none','Location','best');
  if panel==1,ylabel('Regularized objective');else,ylabel('Native relative data misfit');end
 end
 exportgraphics(f,fullfile(folder,sprintf('condition_%02d_trial1_convergence.png',p.condition.id)),'Resolution',160);close(f);
end
end

function writeProtocolTables(root,c)
q=load(fullfile(root,'calibration','locked_calibration.mat'),'cal');cal=q.cal;
parameters={'Grid';'Domain_m';'Frequency_Hz';'Tx_Rx';'ArrayRadius_m';'SNR_dB'; ...
 'TargetRadius_m';'Target_y_m';'Target_x_distribution_m';'BackgroundCorrelationKernelSigma_m'; ...
 'Unknown';'Bounds';'CommonLambdaQuadratic';'CommonLambdaTV';'TVepsilon';'MaxIterations'; ...
 'GradientTolerance';'ObjectiveTolerance';'UpdateTolerance';'FieldTolerance'; ...
 'PrimarySupportThreshold';'SupportThresholdSensitivity';'DefaultTrialSeeds';'MaterialLoss'; ...
 'SelfTerm';'NonlinearInitialization';'SupportExtraction';'RegimeMisfitDefinition'};
values={sprintf('%d x %d cell-centred',c.Nx,c.Ny);sprintf('%.3g x %.3g',c.Lx,c.Ly); ...
 num2str(c.frequency);sprintf('%d colocated reciprocal Tx/Rx',c.nSensors);num2str(c.arrayRadius); ...
 num2str(c.noiseSNRdB);num2str(c.targetRadius);'0.02';'Uniform [-0.02,0.02]';'0.0075'; ...
 'Real total contrast, no oracle background';sprintf('[%.3g,%.3g]',c.lowerBound,c.upperBound); ...
 num2str(cal.lambdaQ);num2str(cal.lambdaTV);num2str(c.tvEpsilon);num2str(c.maxIterations); ...
 num2str(c.gradientTolerance);num2str(c.objectiveTolerance);num2str(c.updateTolerance); ...
 num2str(c.fieldTolerance);num2str(c.primaryThreshold);mat2str(c.thresholds); ...
 sprintf('%d + 100*conditionID + trialID (development adds 10000)',c.seed); ...
 'No; real constitutive contrast only';'Integrated equal-area disk; midpoint off-diagonal'; ...
 'Same Born_Q initializer for both priors; literal zero for NL_TV_Zero'; ...
 ['Magnitude of total contrast; relative peak threshold; locked rule: ' c.detectorRule]; ...
 'Common full-forward relative residual, not native linear residual'};
writetable(table(parameters,values,'VariableNames',{'Parameter','Value'}),fullfile(root,'protocol_table.csv'));
metric={'NativeMisfit';'FullMisfit';'BornForwardDiscrepancy';'Dice';'IoU';'Localization_m'; ...
 'ContrastError';'FDP';'FPR';'PipelineSeconds';'SampledMemoryMaxMiB'};
definition={'norm(y-nativePrediction)/norm(y)';'norm(y-F(reconstruction))/norm(y)'; ...
 'norm(F(truth)-A*truth)/norm(F(truth))';'2*TP/(2*TP+FP+FN)';'TP/(TP+FP+FN)'; ...
 'Distance between binary predicted and true support centroids; NaN for empty support'; ...
 'norm(reconstruction-truth)/norm(truth)';'FP/(TP+FP); NaN for empty support'; ...
 'FP/(FP+TN)';'Solver time plus Born initialization time when used; excludes calibration, generation and evaluation'; ...
 'Maximum sampled process usage during solve, not isolated per-solver peak allocation'};
units={'dimensionless';'dimensionless';'dimensionless';'dimensionless';'dimensionless';'m'; ...
 'dimensionless';'dimensionless';'dimensionless';'s';'MiB'};
writetable(table(metric,definition,units),fullfile(root,'metric_definitions.csv'));
end


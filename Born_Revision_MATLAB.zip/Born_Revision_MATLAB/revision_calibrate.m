function cal=revision_calibrate(op,c,root)
% Sequential independent calibration: lock Q, then tune TV using locked Q starts.
folder=fullfile(root,'calibration');file=fullfile(folder,'locked_calibration.mat');
if exist(file,'file'),q=load(file,'cal');cal=q.cal;return;end
cdv=c;cdv.seed=c.calibrationSeed;
cdv.maxIterations=c.calibrationMaxIterations;cdv.pcgMaxIterations=c.calibrationPCGMaxIterations;
[i,j]=ndgrid(1:c.nSensors);a=min(i,j);b=max(i,j);
val=mod(a+3*b,5)==0;val=val(:);train=~val;
assert(any(val)&&any(train),'Empty calibration split.');
devs=[.02 .20;.10 .35];data=cell(2,1);records=struct([]);initializers=cell(2,1);
for di=1:2
 cond=struct('id',80+di,'h',devs(di,1),'contrast',devs(di,2),'background','correlated');
 d=revision_core('scene',op,cdv,cond,1,true);data{di}=d;
 save(fullfile(folder,sprintf('development_%d.mat',di)),'d','train','val','-v7');
end
selected=zeros(1,2);bracket=false(1,2);allScores=cell(1,2);selectedIndex=zeros(1,2);
for pr=1:2
 if pr==1,candidates=c.lambdaCandidatesQ;names={'Born_Q','NL_Q_BornQ'};kind='quadratic';
 else,candidates=c.lambdaCandidatesTV;names={'Born_TV','NL_TV_BornQ'};kind='tv';end
 for li=1:numel(candidates)
  for di=1:2
   bq=[];d=data{di};
   for mi=1:2
    name=names{mi};x0=zeros(op.N,1);model='linear';
    if mi==2
     model='nonlinear';
     if pr==1,x0=bq;else,x0=initializers{di};end
    end
    stem=sprintf('prior%d_dev%d_lambda%d_%s',pr,di,li,name);
    result=fitCandidate(stem,x0,d,op,cdv,model,kind,candidates(li),train,val,folder);
    if pr==1&&mi==1&&result.success&&result.solver.converged,bq=result.solver.x;end
    r=struct('development',di,'prior',kind,'candidate',li,'lambda',candidates(li), ...
     'method',name,'validationError',Inf,'success',result.success,'converged',false, ...
     'Stop','exception','Iterations',NaN,'FinalProjectedGradient',NaN,'Seconds',NaN);
    if result.success
     r.validationError=result.validationError;r.converged=result.solver.converged;
     r.Stop=result.solver.status;r.Iterations=result.solver.iterations;
     r.FinalProjectedGradient=result.solver.history(end,5);r.Seconds=result.solver.seconds;
    end
    records=revision_append_record(records,r);
    writetable(struct2table(records),fullfile(folder,'development_scores.csv'));
   end
  end
 end
 scores=Inf(numel(candidates),1);
 for li=1:numel(candidates)
  pick=strcmp({records.prior},kind)&[records.candidate]==li;R=records(pick);
  if numel(R)==4&&all([R.success])&&all([R.converged])&&all(isfinite([R.validationError]))
   scores(li)=mean([R.validationError]);
  end
 end
 allScores{pr}=scores;
 writetable(table(candidates(:),scores,'VariableNames',{'Lambda','PooledValidationError'}), ...
  fullfile(folder,[kind '_candidate_summary.csv']));
 [selected(pr),selectedIndex(pr),bracket(pr)]=revision_choose_lambda(candidates,scores);
 if pr==1
  for di=1:2
   q=load(fullfile(folder,sprintf('prior1_dev%d_lambda%d_Born_Q_final.mat',di,selectedIndex(1))),'result');
   initializers{di}=q.result.solver.x;
  end
 end
end
cal=struct('lambdaQ',selected(1),'lambdaTV',selected(2),'records',records, ...
 'scores',{allScores},'trainMask',train,'validationMask',val,'bracketed',all(bracket), ...
 'bracketedByPrior',bracket,'edgeSelected',~all(bracket),'usesTruthForSelection',false, ...
 'selectionRule',['Q first, pooled full-forward held-out residual across both models; TV second ' ...
 'with selected Q initializer; shared lambda per prior; fully converged fits only']);
save(file,'cal','-v7');
fid=fopen(fullfile(folder,'calibration_status.txt'),'w');assert(fid>=0);
cl=onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'Q=%g; TV=%g; converged candidates exist below/above selected Q=%d, TV=%d\n',selected,bracket);
fprintf(fid,'Bracketing is within a discrete tested grid, not proof of a continuous/global optimum.\n');
fprintf('Selected Q=%g TV=%g; bracketed Q=%d TV=%d\n',selected,bracket);
end

function r=fitCandidate(stem,x0,d,op,c,model,kind,lambda,train,val,folder)
final=fullfile(folder,[stem '_final.mat']);
if exist(final,'file'),q=load(final,'result');r=q.result;return;end
r=struct('success',false,'error','');
if isempty(x0),r.error='A converged quadratic initializer was unavailable.';
else
 budgets=unique([c.maxIterations c.calibrationRetryMaxIterations],'stable');
 for attempt=1:numel(budgets)
  part=fullfile(folder,sprintf('%s_attempt%d.mat',stem,attempt));
  if exist(part,'file'),q=load(part,'result');r=q.result;
  else
   cc=c;cc.maxIterations=budgets(attempt);
   fprintf('Calibration %s, budget %d\n',stem,cc.maxIterations);
   try
    s=revision_core('invert',d.y,op,cc,model,kind,lambda,x0,train);
    yp=revision_core('forward',s.x,op,cc,false);
    r=struct('success',true,'error','','solver',s, ...
     'validationError',norm(yp(val)-d.y(val))^2/max(norm(d.y(val))^2,realmin));
   catch ME,r=struct('success',false,'error',getReport(ME,'extended','hyperlinks','off'));end
   result=r;save(part,'result','-v7'); %#ok<NASGU>
  end
  if r.success&&r.solver.converged,break;end
  % Restart from identical initializer at the larger prespecified budget.
 end
end
result=r;save(final,'result','-v7'); %#ok<NASGU>
end

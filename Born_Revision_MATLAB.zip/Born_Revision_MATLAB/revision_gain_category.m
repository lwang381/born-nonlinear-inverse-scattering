function code=revision_gain_category(dm,dd,tm,td)
% 1 neither; 2 data only; 3 joint; 4 Dice only. Absolute gains.
code=ones(size(dm));code(dm>=tm&dd<td)=2;
code(dm>=tm&dd>=td)=3;code(dm<tm&dd>=td)=4;
end
